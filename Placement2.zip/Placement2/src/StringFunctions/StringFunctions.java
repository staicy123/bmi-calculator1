package StringFunctions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StringFunctions {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("*******1. String length() function*******");
		System.out.println("Enter the candidate first name");
		String fname= br.readLine();
		System.out.println("Enter the candidate last name");
		String lname= br.readLine();
		System.out.println("string length is: "+fname.length());  
		System.out.println("string length is: "+lname.length()); 
		
		
		System.out.println("*******2. String compareTo() function*******");
		
		
		System.out.println("Enter the placement officers name");
		String placement_officer1= br.readLine();
		System.out.println("Enter the placement officers name");
		String placement_officer2= br.readLine();
		System.out.println("Enter the placement officers name");
		String placement_officer3= br.readLine();
		System.out.println("Enter the placement officers name");
		String placement_officer4= br.readLine();
		System.out.println(placement_officer1.compareTo(placement_officer2));
		System.out.println(placement_officer1.compareTo(placement_officer3));  
		System.out.println(placement_officer1.compareTo(placement_officer4));  
		
		
		System.out.println("*******3. String concat() function*******");
		
		
		System.out.println("Enter the candidate first name");
		String fname1= br.readLine();
		System.out.println("Enter the candidate last name");
		String lname1= br.readLine();
		System.out.println("string concat is :" +fname1.concat(lname1));
		
		
		System.out.println("*******4. String isEmpty() function*******");
		
		System.out.println("Enter the phone number");
		String phone= br.readLine();
		System.out.println("Enter the email id");
		String email= br.readLine();
		System.out.println("string concat is :" +phone.isEmpty());
		System.out.println("string concat is :" +email.isEmpty());
		
		
		
System.out.println("*******5. String trim() function*******");
		
		
		System.out.println("Enter the job title");
		String job= br.readLine();
		System.out.println(job+"Developer");
		System.out.println(job.trim()+"Developer");
		
		
		
		
System.out.println("*******6. String toLowerCase function*******");
		
		
		System.out.println("Enter the job title");
		String job_title= br.readLine();
		System.out.println(job_title.toLowerCase());
		
		
System.out.println("*******7. String toUpperCase function*******");
		
		
		System.out.println("Enter the job title");
		String job_tit= br.readLine();
		System.out.println(job_tit.toUpperCase());
			
	
		
System.out.println("*******8. String valueOf() function*******");
		
		
			
		int value=20; 
		String year=String.valueOf(value); 
		System.out.println(year+18);   
		
	
		
		
		
		System.out.println("*******9. String replace() function*******");	
		
		String degree="Mtech";
		System.out.println(degree.replace('M', 'B'));
		
		System.out.println("*******10. String contains() function*******");	
		
		
		String name=" You are selected"; 
		System.out.println(name.contains("you"));  
		System.out.println(name.contains("are"));         
		System.out.println(name.contains("not"));   
		
		
		
		
	System.out.println("*******11. String equals() function*******");	
		
		
		String degree1="mtech"; 
		String degree2="Mtech"; 
		String degree3="mtech"; 
		
		System.out.println(degree1.equals(degree2));  
		System.out.println(degree1.equals(degree3));         
	  
		
		System.out.println("*******12. String equalsIgnoreCase() function*******");	
		
		
		String degree11="mtech"; 
		String degree22="Mtech"; 
		String degree33="mtech"; 
		
		System.out.println(degree11.equalsIgnoreCase(degree22));  
		System.out.println(degree11.equalsIgnoreCase(degree33));        
		
		
		System.out.println("*******13. String toCharArray() function*******");	
		
		String s1="Welcome to PlacementApp";
		char[] ch=s1.toCharArray();
		for(int i=0;i<ch.length;i++){
		System.out.print(ch[i]);}
		
		System.out.println("*******14. String endsWith() function*******");
		
	  
		String text1="Enter candidate name";
			System.out.println(text1.endsWith("e"));      
			System.out.println(text1.endsWith("name"));       
				System.out.println(text1.endsWith("enter")); 
				
				
			
			System.out.println("*******15. String startsWith() function*******");
			
			
			
			
			String text2="Enter candidate name";
			System.out.println(text2.startsWith("E"));      
			System.out.println(text2.startsWith("Enter"));       
				System.out.println(text2.startsWith("name")); 
				
				
				System.out.println("*******16. String subString() function*******");
				
				String name1="SachinMohan";  
				   System.out.println(name1.substring(6));
				   System.out.println(name1.substring(0,6)); 
				   
			   
				   
				   System.out.println("*******17. String indexOf() function*******");
				   
				   String index = new String("Welcome to Placement App");
				      System.out.print("Found Index :" );
				      System.out.println(index.indexOf( 't' ));
				      
				      
				      
				      System.out.println("*******18. String split() function*******"); 
				      
				      String text3 = "Placement@Cell@Officer";
				        String [] arrOfStr = text3.split("@", 3);
				 
				        for (String a : arrOfStr)
				            System.out.println(a);
				        
				       
				        System.out.println("*******19. String charAt() function*******"); 
				        String text4 = "Placement@Cell@Officer";
				        System.out.println(text4.charAt(5));
				        System.out.println(text4.charAt(8));
				        
				        
				        
				        System.out.println("*******20. String intern() function*******");  
				        
				        String str1=new String("CollegeStudent");  
				        String str2=str1.intern();  
				        System.out.println(str2);
				        
	}

}
