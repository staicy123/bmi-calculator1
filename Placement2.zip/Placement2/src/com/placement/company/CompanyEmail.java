package com.placement.company;

import java.io.BufferedReader;
import java.io.IOException;

import com.placement.PlacementDatabase;

public class CompanyEmail {
	
	
	String company_id;
	String email;
	String password;
	public CompanyEmail() {
		super();
	}
	public CompanyEmail(String company_id,String email, String password) {
		super();
		this.email = email;
		this.password = password;
		this.company_id=company_id;
		
	}
	
	public String getCompany_id() {
		return company_id;
	}
	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public void EmailandPassword(BufferedReader br,PlacementDatabase db,String comp_id) throws IOException{
		
		
		
		this.company_id=comp_id;
		System.out.println("Enter the email id");
		String email = br.readLine();
		System.out.println("Enter Email Password");
		String password= br.readLine();
		
		CompanyEmail company_email = new CompanyEmail(company_id,email,password);
		db.addCompanyEmail(company_email);
		
		
	}

}
