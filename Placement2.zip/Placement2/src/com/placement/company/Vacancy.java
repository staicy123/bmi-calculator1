package com.placement.company;

public class Vacancy {

	private String vac_id; //VacancyDate id
	private String job; //Job title
	private String contact; //Contact mail-id
	private String posteddate;//vacancy posted date
	private String posted_timing;
	private String closedate; //Closing date of vacancy
	private String close_timing;
	private String qual; //Qualification for that job
	private String exp; //Number of experience for that job
	private String location; //Job location
	private String status; //Tells whether the vacancy is expired or not
	private String clg_id;
	private String company_name;
	private String no_of_vacancy;
	
	
	
	public String getNo_of_vacancy() {
		return no_of_vacancy;
	}


	public void setNo_of_vacancy(String no_of_vacancy) {
		this.no_of_vacancy = no_of_vacancy;
	}


	public Vacancy() {
		super();
	}
	
	
	public Vacancy(String vac_id, String job, String contact, String posteddate,String closedate,
			String qual, String exp, String location, String status,String clg_id,String no_of_vacancy) {
		super();
		this.vac_id = vac_id;
		this.job = job;
		this.contact = contact;
		this.posteddate=posteddate;
		this.posted_timing=posted_timing;
		this.closedate = closedate;
		this.close_timing=close_timing;
		this.qual = qual;
		this.exp = exp;
		this.location = location;
		this.status = status;
		this.clg_id=clg_id;
		this.no_of_vacancy=no_of_vacancy;
	}
	

	public String getCompany_name() {
		return company_name;
	}


	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}


	public String getPosted_timing() {
		return posted_timing;
	}

	public void setPosted_timing(String posted_timing) {
		this.posted_timing = posted_timing;
	}

	public String getClose_timing() {
		return close_timing;
	}

	public void setClose_timing(String close_timing) {
		this.close_timing = close_timing;
	}

	public String getPosteddate() {
		return posteddate;
	}

	public void setPosteddate(String posteddate) {
		this.posteddate = posteddate;
	}

	public String getClg_id() {
		return clg_id;
	}

	public void setClg_id(String clg_id) {
		this.clg_id = clg_id;
	}

	public String getVac_id() {
		return vac_id;
	}


	public void setVac_id(String vac_id) {
		this.vac_id = vac_id;
	}


	public String getJob() {
		return job;
	}


	public void setJob(String job) {
		this.job = job;
	}


	public String getContact() {
		return contact;
	}


	public void setContact(String contact) {
		this.contact = contact;
	}


	public String getClosedate() {
		return closedate;
	}


	public void setClosedate(String closedate) {
		this.closedate = closedate;
	}


	public String getQual() {
		return qual;
	}


	public void setQual(String qual) {
		this.qual = qual;
	}


	public String getExp() {
		return exp;
	}


	public void setExp(String exp) {
		this.exp = exp;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
