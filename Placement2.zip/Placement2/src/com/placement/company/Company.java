package com.placement.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.placement.PlacementDatabase;
import com.placement.PrimaryActionListener;
import com.placement.Validation;

public class Company implements PrimaryActionListener{

	private String compid; //Company ID
	private String compname; //Name of company
	private String addr_line1; //Company Address line1
	private String pincode; //Pincode
	private String city; //LOcation of company
	private String hr_name; //First Name of HR
	private String phone; //Contact number
	private String email; //Company e-mail taken as username
	private String url; //Company URL
	private String pass; //login password of companies
	private List<Vacancy> vaclist;
		
	public Company() {
		super();
	}

	public Company(String compid, String compname, String addr_line1,
			String pincode, String city, String hr_name, String phone,
			String email, String url, String pass, List<Vacancy> vaclist) {
		super();
		this.compid = compid;
		this.compname = compname;
		this.addr_line1 = addr_line1;
		this.pincode = pincode;
		this.city = city;
		this.hr_name = hr_name;
		this.phone = phone;
		this.email = email;
		this.url = url;
		this.pass = pass;
		this.vaclist = vaclist;
	}

	public Company(String compid, String compname, 
			 String hr_name, String phone,
			String email, String pass) {
		super();
		this.compid = compid;
		this.compname = compname;
		this.addr_line1 = addr_line1;
		this.pincode = pincode;
		this.city = city;
		this.hr_name = hr_name;
		this.phone = phone;
		this.email = email;
		this.url = url;
		this.pass = pass;
		this.vaclist = vaclist;
	}

	public String getCompid() {
		return compid;
	}

	public void setCompid(String compid) {
		this.compid = compid;
	}

	public String getCompname() {
		return compname;
	}

	public void setCompname(String compname) {
		this.compname = compname;
	}

	public String getAddr_line1() {
		return addr_line1;
	}

	public void setAddr_line1(String addr_line1) {
		this.addr_line1 = addr_line1;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHr_name() {
		return hr_name;
	}

	public void setHr_name(String hr_name) {
		this.hr_name = hr_name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public List<Vacancy> getVaclist() {
		return vaclist;
	}

	public void setVaclist(List<Vacancy> vaclist) {
		this.vaclist = vaclist;
	}

	public void register() throws IOException {
		// TODO Auto-generated method stub
		PlacementDatabase db = new PlacementDatabase();
		String pincode,hr,phone,email,url;
		boolean yes;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String comp_id,comp_name,hr_name,phone_no,cmail,password;
		System.out.println("Enter company id : ");	
		comp_id=br.readLine();
		System.out.println("Company name : "); 
		comp_name=br.readLine();
		
		for(;;){
			System.out.println("Name of HR : "); 
			hr_name=br.readLine();
			yes=Validation.validateLetters(hr_name);
			if(yes)
				break;
			else	System.out.println("HR name is not valid. Enter again");
		}
		
		for(;;){
			System.out.println("Phone number : "); 
			phone_no=br.readLine();
			yes=Validation.validatePhoneNumber(phone_no);
			if(yes)
				break;
			else	System.out.println("Phone number is not valid. Enter again");
		}
		
		for(;;){
			System.out.println("Company mail : "); 
			cmail=br.readLine();
			yes=Validation.validateEmail(cmail);
			if(yes)
				break;
			else	System.out.println("Email not valid. Enter again");
		}
		
		

		System.out.println("Password : ");
		password=br.readLine();
		//comp_id,comp_name,hr_name,phone_no,cmail,password;
		Company company = new Company(comp_id,comp_name,hr_name,phone_no,cmail,password);
		db.addCompanyReg(company);
		
	}
	
}
