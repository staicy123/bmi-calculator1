package com.placement;

import java.io.BufferedReader;
import java.io.IOException;

import com.placement.candidate.Candidate;

public class EducationalDetails extends Candidate{
	
	
	EducationalDetails edu;

	private String postgraduate;
	private String marks1;
	private String passed_out_year1;
	private String graduate;
	private String marks;
	private String passed_out_year;
	private int candid;
	
	
	public EducationalDetails() {
		super();
	}


	public EducationalDetails(int candid,String postgraduate, String marks1,
			String passed_out_year1, String graduate, String marks,
			String passed_out_year) {
		//super(canid);
		//canid=canid;
		this.candid=candid;
		this.postgraduate = postgraduate;
		this.marks1 = marks1;
		this.passed_out_year1 = passed_out_year1;
		this.graduate = graduate;
		this.marks = marks;
		this.passed_out_year = passed_out_year;
	}
	
	
	public EducationalDetails(int candid,String graduate, String marks,
			String passed_out_year) {
		//super(canid);
		//canid=canid;
		this.candid=candid;
		this.graduate = graduate;
		this.marks = marks;
		this.passed_out_year = passed_out_year;
	}

	
	

	


	public int getCandid() {
		return candid;
	}


	public void setCandid(int candid) {
		this.candid = candid;
	}


	public String getPostgraduate() {
		return postgraduate;
	}



	public void setPostgraduate(String postgraduate) {
		this.postgraduate = postgraduate;
	}



	public String getMarks1() {
		return marks1;
	}



	public void setMarks1(String marks1) {
		this.marks1 = marks1;
	}



	public String getPassed_out_year1() {
		return passed_out_year1;
	}



	public void setPassed_out_year1(String passed_out_year1) {
		this.passed_out_year1 = passed_out_year1;
	}



	public String getGraduate() {
		return graduate;
	}



	public void setGraduate(String graduate) {
		this.graduate = graduate;
	}



	public String getMarks() {
		return marks;
	}



	public void setMarks(String marks) {
		this.marks = marks;
	}



	public String getPassed_out_year() {
		return passed_out_year;
	}



	public void setPassed_out_year(String passed_out_year) {
		this.passed_out_year = passed_out_year;
	}
	
	
	public void setFaithEducationaldetails(int faith_id,BufferedReader br,PlacementDatabase db) throws IOException{
		
		String post,post_year,post_mark,graduate,grad_year,grad_mark;
		int choice;
		boolean yes=true;
		do{
			System.out.println("1.Post graduate   2.graduate  3.Exit");
			choice=Integer.parseInt(br.readLine());
			switch(choice)
			{
			case 1:
				this.candid=faith_id;
				System.out.println("Enter post graduation degree");
				post = br.readLine();
				
				
				for(;;){
					System.out.print("Enter passed out year (eg : yyyy) : ");
					post_year=br.readLine();
					yes=Validation.validateYear1(post_year);
					if(yes)
						break;
					else	System.out.println("Passed out year is not valid");
				}
				
				
				System.out.println("Enter cgpa");
				post_mark = br.readLine();
				System.out.println("Enter graduation degree");
				graduate = br.readLine();
				
				for(;;){
					System.out.print("graduation passed out year (eg : yyyy) : ");
					grad_year=br.readLine();
					yes=Validation.validateYear1(grad_year);
					if(yes)
						break;
					else	System.out.println("Passed out year is not valid");
				}
				
				
				System.out.println("Enter cgpa");
				grad_mark = br.readLine();
				
				edu= new EducationalDetails(candid,post,post_mark,post_year,graduate,grad_mark,grad_year);
				db.addPostGraduation(edu,candid);
				break;
				
			case 2:
				
				this.candid=faith_id;
				System.out.println("Enter graduation degree");
				graduate = br.readLine();
				for(;;){
					System.out.print("graduation passed out year (eg : yyyy) : ");
					grad_year=br.readLine();
					yes=Validation.validateYear1(grad_year);
					if(yes)
						break;
					else	System.out.println("Passed out year is not valid");
				}
				System.out.println("Enter cgpa");
				grad_mark = br.readLine();
				
				edu= new EducationalDetails(candid,graduate,grad_mark,grad_year);
				db.addGraduation(edu);
				break;
				
			}
		}while(choice!=3);
		
		
		
	}
	
}
