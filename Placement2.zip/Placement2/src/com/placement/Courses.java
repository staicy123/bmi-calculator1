package com.placement;

import java.io.BufferedReader;
import java.io.IOException;

public class Courses {
	
	
	int id;
	String course_name;

	public Courses() {
		super();
	}

	public Courses(String course_name) {
		super();
		//this.id = id;
		this.course_name = course_name;
	}
	
	
	
	
	
	public Courses(int id, String course_name) {
		super();
		this.id = id;
		this.course_name = course_name;
	}






	public int getId() {
		return id;
	}






	public void setId(int id) {
		this.id = id;
	}






	public String getCourse_name() {
		return course_name;
	}






	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}






	public void addCourses(BufferedReader br,PlacementDatabase db) throws IOException{
		
		
		System.out.println("Enter the course");
		String course_name=br.readLine();
		
		Courses course= new Courses(course_name);
		db.addCourses(course);
		
	}

}
