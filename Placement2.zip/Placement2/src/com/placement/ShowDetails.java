package com.placement;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.placement.company.Company;
import com.placement.company.Vacancy;
import com.placement.placementcell.College;
import com.placement.placementcell.CollegeCandidateDisplay;
import com.placement.placementcell.PlacementOfficer;
import com.placement.placementcell.University;





public class ShowDetails {
	//List<University> univers;
	
	//Admin can view all candidates PLIDs and details
	public static void displayPLIDS(List<PLIDS> pllist){
		System.out.println("\n\tFaith Trainees");
		System.out.println("--------------");
		if(pllist.size()==0){
			System.out.println("No Trainees Available");
		}
		else{
			System.out.println("PLID    BatchName   CourseName   Year");
			for(int i=0;i<pllist.size();i++){
				System.out.println(pllist.get(i).getPLID()+"  "+pllist.get(i).getBatch()+"  "+pllist.get(i).getCrs_name()+"  "+pllist.get(i).getYear());
			}
		}
	}
	
	
	public static List<Vacancy> displayvacancy(List<Vacancy> vacancy){
		int i=0;String status="Open";
		if(vacancy.size()==0)
		{
				System.out.println("No records added");
		}
		else
		{
				//System.out.println("\t\t -7%s  \n","vacancy id");
				System.out.println("vacancy id          Job Name            email               Posted Date                             Closing Date              Experience     Qualification       Location       Status");
				for( i=0;i<vacancy.size();i++){ 
					if(status.equals(vacancy.get(i).getStatus())){
					
					System.out.println(vacancy.get(i).getVac_id()+ "\t\t" +vacancy.get(i).getJob()+ "\t\t" +vacancy.get(i).getContact()+ "\t\t" +vacancy.get(i).getPosteddate()+ "\t\t" +vacancy.get(i).getClosedate()+ "\t\t" +vacancy.get(i).getExp() +"\t\t" +vacancy.get(i).getQual()+ "\t\t" +vacancy.get(i).getLocation()+ "\t\t" +vacancy.get(i).getStatus());
					}
					}
	}
		return vacancy;
	}
	//Details of all job vacancies
	public static void displayVacancy(List<Company> cmplist,List<Vacancy> vclist){
		System.out.println("\n\tCompany VacancyDate");
		System.out.println("---------------");
		if(vclist.size()==0){
			System.out.println("No Vacancies Reported");
		}
		else{
			System.out.println("\nVacancyFor   SendMailTo   CloseOn   Qualification   Experience   JobLocation");
			for(int j=0;j<cmplist.size();j++){
				vclist=cmplist.get(j).getVaclist();
				for(int i=0;i<vclist.size();i++){
					System.out.println(vclist.get(i).getJob()+"  "+vclist.get(i).getContact()+"  "+vclist.get(i).getClosedate()+"  "+vclist.get(i).getClosedate()+"   "+vclist.get(i).getExp()+"   "+vclist.get(i).getLocation());
				}
			}
		}
	}
	
	public static List<University> displayUniversityList(List<University> univers){
		if(univers.size()==0)
		{
				System.out.println("No records added");
		}
		else
		{
				
				System.out.println("UniversityId\tUniversityName");
				for(int i=0;i<univers.size();i++){
					System.out.println(univers.get(i).getUniversity_id()+ "\t\t\t\t" +univers.get(i).getUniversity_name());
		}
	}
		return univers;
	}
	
	public static List<Courses> displayCourses(List<Courses> course){
		if(course.size()==0)
		{
				System.out.println("No records added");
		}
		else
		{
				
				System.out.println("CourseId\tCourse Name");
				for(int i=0;i<course.size();i++){
					System.out.println(course.get(i).getId()+ "\t\t\t\t" +course.get(i).getCourse_name());
		}
	}
		return course;
	}
	
	
	public static void deleteUniversityList(List<University> univers, BufferedReader br) throws IOException{
		PlacementDatabase db= new PlacementDatabase();
		boolean status=false;
		if(univers.size()==0)
		{
				System.out.println("No records found to delete");
		}
		else
		{
				
				System.out.println("UniversityId\tUniversityName");
				for(int i=0;i<univers.size();i++){
					System.out.println(univers.get(i).getUniversity_id()+ "\t\t\t\t" +univers.get(i).getUniversity_name());
		}
				do{
				System.out.println("Enter the university id you want to delete");
				String id=br.readLine();
				for(int i=0;i<univers.size();i++){
				if(id.equals(univers.get(i).getUniversity_id())){
					db.deleteUniversity(id);
					status=true;
					break;
					
				}
					}
				if(status!=true){
					System.out.println("You have entered worng id");
				}
				}while(status==false);
				
	}
	}
	public static void displayCollegeList(List<College> college)
	{
		if(college.size()==0)
		{
				System.out.println("No records added");
		}
		else
		{
			System.out.println("Collegeid\tCollegename\tAddress\tEmail\tPhone\tUniversityid");
			for(int i=0;i<college.size();i++){
				System.out.println(college.get(i).getCollege_id()+ "\t\t" +college.get(i).getCollege_name()+ "\t\t" +college.get(i).getAddress()+ "\t\t" +college.get(i).getEmail()+ "\t\t" +college.get(i).getPhone()+ "\t\t" +college.get(i).getUniversity().getUniversity_id());
		}
	}
	}
	
	
	
	public static void displayRecruiterDetails(List<Company> company)
	{
		if(company.size()==0)
		{
				System.out.println("No records added");
		}
		else
		{
			System.out.println("Company id        Company name        Hr Name             Phone              Email");
			for(int i=0;i<company.size();i++){
				System.out.println(company.get(i).getCompid()+ "\t\t" +company.get(i).getCompname()+ "\t\t" +company.get(i).getHr_name()+ "\t\t" +company.get(i).getPhone()+ "\t\t" +company.get(i).getEmail());
		}
	}
	}
	
	
	
	
	
	
	
	
	public static List<String> displayPlacementOfficerList(List<PlacementOfficer> course){
		List<String> num = new ArrayList<String>();
		if(course.size()==0)
		{
				System.out.println("No records added");
		}
		else
		{
				
				System.out.printf("%-30s %-20s %-20s   %-20s\n" ,"College Id","Placement Officer Name ","Officer MailId ","College Name");
				for(int i=0;i<course.size();i++){
					System.out.println(course.get(i).getCollege_id()+ "\t\t\t" +course.get(i).getPlacement_officer_name()+ "\t\t\t" +course.get(i).getEmail()+ "\t\t" +course.get(i).getCollege_name());
					num.add(course.get(i).getCollege_id());
				
				}
	}
		return num;
	}
	
	public static String displayPlacementOfficerList1(List<PlacementOfficer> course,String num1){
		String num = null;
		if(course.size()==0)
		{
				System.out.println("No records added");
		}
		else
		{
				
				System.out.println(" Placement Officer Name       Officer MailId   ");
				for(int i=0;i<course.size();i++){
					if(num1.equals(course.get(i).getCollege_id())){
					System.out.println(course.get(i).getPlacement_officer_name()+ "\t\t\t\t" +course.get(i).getEmail());
					num=course.get(i).getEmail();
					}
				
				}
	}
		return num;
	}
	
	
	public static void displayCollegeCandidateList(List<CollegeCandidateDisplay> course){
		String num = null;
		if(course.size()==0)
		{
				System.out.println("No records added");
		}
		else
		{
				
				System.out.printf("%-30s %-40s %-20s   %-20s %-20s %-20s %-20s %-20s\n","Candidate Name","Email ID","Postgraduation","Pg_cgpa","Pg_passsed_out_year" ,"Graduation"," G_cgpa","G_passed_out_year");
				for(int i=0;i<course.size();i++){
					System.out.println(course.get(i).getCandidate_name()+ "\t\t\t" +course.get(i).getEmail()+ "\t\t\t" +course.get(i).getPostgraduation()+ "\t\t\t" +course.get(i).getP_marks()+ "\t\t\t" +course.get(i).getP_passed_out_year()+ "\t\t\t" +course.get(i).getGraduation()+ "\t\t"+course.get(i).getG_marks()+ "\t\t\t" + course.get(i).getG_passed_out_year());
					//num=course.get(i).getCollege_id();
				
				}
	}
		//return num;
	}
	
}
