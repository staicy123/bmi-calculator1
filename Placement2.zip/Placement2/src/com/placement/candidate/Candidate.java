package com.placement.candidate;

import com.placement.PLIDS;

public class Candidate {

	private int canid; //Candidate ID
	private String name; //Name of candidate
	private String dob; //date of birth of candidate
	private String addr_line1; //Candidate Address line1
	private String pincode; //Pincode
	private String city; //place of candidate
	private String mob; //Contact number of candidate
	private String cmail; //E-mail of candidate considered as the username
	private String pass; //Password
	private String status; //status tells whether the candidate is placed somewhere or not
	//private PLIDS plid;
	
	public Candidate() {
		super();
	}
	public Candidate(int canid) {
		super();
		this.canid=canid;
	}
	
	public Candidate( String dob, String mob,String pincode ,String pass) {
		super();	
		//this.name = name;
		this.dob = dob;
		this.mob = mob;
		this.pincode =pincode;
		this.pass = pass;
	
	}
	public Candidate(String name,String cmail) {
		super();
		
		this.name = name;
		
		this.cmail = cmail;
		this.pass = pass;
	
	}

	
	
	public Candidate(String name, String dob,
			String pincode,String mob, String cmail, String pass) {
		super();
		//this.canid = canid;
		this.name = name;
		this.dob = dob;
		//this.addr_line1 = addr_line1;
		this.pincode = pincode;
		//this.city = city;
		this.mob = mob;
		this.cmail = cmail;
		this.pass = pass;
		//this.plid=plid;
		//this.status = status;
	}

	public Candidate(int canid, String name, String dob, String addr_line1,
			String pincode, String city, String mob, String cmail, String pass,
			String status) {
		super();
		this.canid = canid;
		this.name = name;
		this.dob = dob;
		this.addr_line1 = addr_line1;
		this.pincode = pincode;
		this.city = city;
		this.mob = mob;
		this.cmail = cmail;
		this.pass = pass;
		this.status = status;
	}


	public int getCanid() {
		return canid;
	}


	public void setCanid(int canid) {
		this.canid = canid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getAddr_line1() {
		return addr_line1;
	}


	public void setAddr_line1(String addr_line1) {
		this.addr_line1 = addr_line1;
	}


	public String getPincode() {
		return pincode;
	}


	public void setPincode(String pincode) {
		this.pincode = pincode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getMob() {
		return mob;
	}


	public void setMob(String mob) {
		this.mob = mob;
	}


	public String getCmail() {
		return cmail;
	}


	public void setCmail(String cmail) {
		this.cmail = cmail;
	}


	public String getPass() {
		return pass;
	}


	public void setPass(String pass) {
		this.pass = pass;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
