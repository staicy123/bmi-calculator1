package com.placement.candidate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.placement.PlacementDatabase;
import com.placement.PrimaryActionListener;
import com.placement.Validation;
import com.placement.placementcell.College;

public class CollegeCandidate extends Candidate implements PrimaryActionListener{
	
	College college;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	PlacementDatabase db= new PlacementDatabase();
	
	
	public CollegeCandidate()
	{
		
	}

	public CollegeCandidate(College college_id) {
		super();
		this.college=college;
	}

	// pending
	
	public CollegeCandidate( String dob, String mob,String pincode,
			 String pass) {
		super(dob, mob,pincode,pass);
		this.college = college;
		// TODO Auto-generated constructor stub
	}
	public CollegeCandidate(String name,String cmail,College college) {
		super(name,cmail);
		this.college = college;
		// TODO Auto-generated constructor stub
	}

	public College getCollege() {
		return college;
	}

	public void setCollege_id(College college_id) {
		this.college = college;
	}

	public void register() throws IOException, ClassNotFoundException {
		
			//System.out.println("CollegeCandidate registration");
			String dob,pincode,mob,pass;
			boolean yes,status=false;
			List <CollegeCandidate> coll1= db.getCollegeCandidateList();
			/*for(int i=0;i<coll1.size();i++)
			{
				System.out.println("college email"+coll1.get(i).getCmail());
			}*/
			System.out.println("Enter your name");
			String name= br.readLine();
			System.out.println("Enter email id");
			String email=br.readLine();
			
			
			for(int i=0;i<coll1.size();i++)
			{
				if(email.equals(coll1.get(i).getCmail()))
						{
		// TODO Auto-generated method stub	
		
						for(;;){
							System.out.print("Date of birth (eg : dd/mm/yyyy) : ");
							dob=br.readLine();
							yes=Validation.validateDob(dob);
							if(yes)
								break;
							else	
								System.out.println("Date is not valid.Enter again");
						}
						
					
		
						
						for(;;){
							System.out.println("Contact number : "); mob=br.readLine();
							yes=Validation.validatePhoneNumber(mob);
							if(yes)
								break;
							else	
								System.out.println("Phone number is not valid.Enter again");
							}
							for(;;){
								System.out.print("Pincode : "); 
								pincode=br.readLine();
								yes=Validation.validatePincode(pincode);
								if(yes)
									break;
								else	
									System.out.println("Pincode is not valid.Enter again");
							}
		
					
							System.out.print("Enter password : "); 
							pass=br.readLine();
						
							CollegeCandidate candidate = new CollegeCandidate(dob,mob,pincode,pass);
							db.updateCandidate(candidate,name);
							status=true;
							break;
						
							}
				}
				if(status==false)
				{
					System.out.println("You are not a registered candidate");
				//break;
				}
						
		
		}
	
	public void addCandidate(String id) throws IOException, ClassNotFoundException
	{
		String name,email,college_id;
		boolean yes;
		
		for(;;){
			System.out.print("Candidate name : ");
			name=br.readLine();
			yes=Validation.validateLetters(name);
			if(yes)
				break;
			else	
				System.out.println("Name is not valid.Enter again");
			}
		
		for(;;){
			System.out.print("E_mail id : "); email=br.readLine();
			yes=Validation.validateEmail(email);
			if(yes)
				break;
			else	
				System.out.println("Email is not valid.Enter again");
		}
		boolean status,status1=false;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		List<College> col = db.getCollegeList();
		System.out.println("College id");
		//for(;;){
				
				System.out.println(id);
				//}
				/*do{
					System.out.println("Select college id");
					college_id=br.readLine();
					for(int i=0 ; i<col.size(); i++){
						if(college_id.equals(col.get(i).getCollege_id())){
							status1=true;
							break;
							}
					}
						if(status1==false){
							System.out.println("Enter valid id from the above list");
							//status1=false;
							break;
						
						}
					
				}while(status1!=true);*/
		College coll= new College(id);
		CollegeCandidate candidate1 = new CollegeCandidate(name,email,coll);
		db.addCandidate(candidate1);
		
	}

}
