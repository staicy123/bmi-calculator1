package com.placement.candidate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.placement.PLIDS;
import com.placement.PlacementDatabase;
import com.placement.PrimaryActionListener;
import com.placement.Validation;

public class FaithCandidate extends Candidate/* implements PrimaryActionListener*/ {
	
	private String plobj;
	PlacementDatabase db = new PlacementDatabase();
	String name,dob,pincode,mob,email,pass;
//	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	public FaithCandidate() {
		super();
	}

	public FaithCandidate(String name, String dob, String pincode, String mob,
			String cmail, String pass, String plobj) {
		super( name, dob, pincode, mob, cmail, pass);
		this.plobj = plobj;
	}
	
	

	public String getPlobj() {
		return plobj;
	}

	public void setPlobj(String plobj) {
		this.plobj = plobj;
	}
	

	public void register(String plids) throws IOException, ClassNotFoundException {
	
		// TODO Auto-generated method stub
		
		boolean yes,status=true;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
				//this.plids=plids;
				
			//	System.out.println(plids);
				for(;;){
					System.out.print("Candidate name : ");
					name=br.readLine();
					yes=Validation.validateLetters(name);
					if(yes)
						break;
					else	System.out.println("Name is not valid.Enter again");
				}
				
				//for(;;){
					System.out.print("Date of birth (eg : dd/mm/yyyy) : ");
					dob=br.readLine();
				//	yes=Validation.validateDob(dob);
				//	if(yes)
					//	break;
				//	else	System.out.println("Date is not valid.Enter again");
			//	}
				
				for(;;){
					System.out.print("Pincode : ");
					pincode=br.readLine();
					yes=Validation.validatePincode(pincode);
					if(yes)
						break;
					else	System.out.println("Pincode is not valid.Enter again");
				}
				
				
				for(;;){
					System.out.println("Contact number : ");
					mob=br.readLine();
					yes=Validation.validatePhoneNumber(mob);
					if(yes)
						break;
					else	System.out.println("Phone number is not valid.Enter again");
				}
				
				for(;;){
					System.out.print("E_mail id : "); email=br.readLine();
					yes=Validation.validateEmail(email);
					if(yes)
						break;
					else	System.out.println("Email is not valid.Enter again");
				}
				
				System.out.print("Enter password : "); pass=br.readLine();
				//this.setStatus("pending");
				//status=true;break;
			
			
			
		//PLIDS pl = new PLIDS(plids);
		//System.out.println(pl);
		//List<FaithCandidate> cand= db.getfaithCandidate();	
		FaithCandidate faith = new FaithCandidate(name,dob,pincode,mob,email,pass,plids);
		db.addFaithCandidate(faith);
		
		/*if(status==false){
			System.out.println("You have entered wrong plid or not a faith candidate");
			break;
		}*/
	}//
				
			}
		
		
		
		
		
		


