package com.placement.candidate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.placement.PlacementDatabase;
import com.placement.PrimaryActionListener;
import com.placement.Validation;

public class OtherCandidate extends Candidate implements PrimaryActionListener {

	public OtherCandidate(){
		
	}
	
	public OtherCandidate( String name, String dob,
			 String pincode,  String mob,
			String cmail, String pass) {
		super(name, dob, pincode, mob, cmail, pass);
	}
	
	public void register() throws IOException {
		// TODO Auto-generated method stub
		String name,dob,pincode,mob,email,password;
		boolean yes;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		
		for(;;){
			System.out.print("Candidate name : ");name=br.readLine();
			yes=Validation.validateLetters(name);
			if(yes)
				break;
			else	System.out.println("Name is not valid.Enter again");
		}
		
		for(;;){
			System.out.print("Date of birth (eg : dd/mm/yyyy : "); dob=br.readLine();
			yes=Validation.validateDob(dob);
			if(yes)
				break;
			else	System.out.println("Date is not valid.Enter again");
		}
		
		for(;;){
			System.out.print("Pincode : "); pincode=br.readLine();
			yes=Validation.validatePincode(pincode);
			if(yes)
				break;
			else	System.out.println("Pincode is not valid.Enter again");
		}
		
		
		for(;;){
			System.out.println("Contact number : "); mob=br.readLine();
			yes=Validation.validatePhoneNumber(mob);
			if(yes)
				break;
			else	System.out.println("Phone number is not valid.Enter again");
		}
		
		for(;;){
			System.out.print("E_mail id : "); email=br.readLine();
			yes=Validation.validateEmail(email);
			if(yes)
				break;
			else	System.out.println("Email is not valid.Enter again");
		}
		
		System.out.print("Enter password : ");
		password=br.readLine();
		
		
		OtherCandidate other = new OtherCandidate(name,dob,pincode,mob,email,password);
		PlacementDatabase db = new PlacementDatabase();
		db.addOtherCandidate(other);

		//this.setStatus("pending");

	}

}
