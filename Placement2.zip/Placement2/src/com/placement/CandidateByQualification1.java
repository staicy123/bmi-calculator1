package com.placement;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class CandidateByQualification1 {

public void getStudentAppliedList(List <VacancyList> vacant) throws ClassNotFoundException, DocumentException, FileNotFoundException{
		
		
			
				
				
				Document document = new Document(PageSize.A4, 10, 10, 10, 10);
				//G://FaithPlacementApp/GeneratedPDFs/sample.pdf
				Date d=new Date();
				//path="G://FaithPlacementApp/GeneratedPDFs/"+d+".pdf";
				PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream("D://candidates.pdf"));
				document.open();
				//String status = "Applied";
				
				Paragraph para1 = new Paragraph("Candidates by qualification",FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLD, new CMYKColor(60, 40, 40, 100)));
				document.add(para1);
				PdfPTable t = new PdfPTable(6);
					t.setSpacingBefore(25);
					t.setSpacingAfter(25);
					PdfPCell c1 = new PdfPCell(new Phrase("Candidate Name"));		t.addCell(c1);
					PdfPCell c2 = new PdfPCell(new Phrase("Email Id"));				t.addCell(c2);
					PdfPCell c3 = new PdfPCell(new Phrase("Post graduate degree"));		t.addCell(c3);
					PdfPCell c4 = new PdfPCell(new Phrase("Post graduate cgpa"));	t.addCell(c4);
					PdfPCell c5 = new PdfPCell(new Phrase("Post graduate passed out year"));				t.addCell(c5);
					
					PdfPCell c6 = new PdfPCell(new Phrase("Applied job id"));				t.addCell(c6);
					
					
					
				for(int i=0;i<vacant.size();i++){
					
					
						//pstmt.setInt(1, rs.getInt("canid"));
						//rs2=pstmt.executeQuery();
					
					t.addCell(vacant.get(i).getCandname());
					
					t.addCell(vacant.get(i).getEmailid());
					
					t.addCell(vacant.get(i).getPost_grad());
					
					t.addCell(vacant.get(i).getMarks());
					//addCell.add(new PdfPCell(id));
					
					t.addCell(vacant.get(i).getPassed_out_year());
					
					t.addCell(vacant.get(i).getVacancy_id());
						
				}
				document.add(t);
				document.close();
				System.out.println("\tPDF download complete");
				
				
			
			
	}
	
/*public void getCallletter(List <VacancyInterviewList> vacant) throws ClassNotFoundException, DocumentException, FileNotFoundException{
	
	
	
	
	
	Document document = new Document(PageSize.A4, 10, 10, 10, 10);
	//G://FaithPlacementApp/GeneratedPDFs/sample.pdf
	Date d=new Date();
	//path="G://FaithPlacementApp/GeneratedPDFs/"+d+".pdf";
	PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream("D://callletter.pdf"));
	document.open();
	//String status = "Applied";
	
	Paragraph para1 = new Paragraph("Call letter",FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLD, new CMYKColor(60, 40, 40, 100)));
	document.add(para1);
	PdfPTable t = new PdfPTable(3);
		t.setSpacingBefore(25);
		t.setSpacingAfter(25);
		PdfPCell c1 = new PdfPCell(new Phrase("Candidate Name"));		t.addCell(c1);
		PdfPCell c2 = new PdfPCell(new Phrase("Email Id"));				t.addCell(c2);
		PdfPCell c3 = new PdfPCell(new Phrase("Post graduate degree"));		t.addCell(c3);
		PdfPCell c4 = new PdfPCell(new Phrase("Post graduate cgpa"));	t.addCell(c4);
		PdfPCell c5 = new PdfPCell(new Phrase("Post graduate passed out year"));				t.addCell(c5);
		
		PdfPCell c6 = new PdfPCell(new Phrase("Applied job id"));				t.addCell(c6);
		
		
		
	for(int i=0;i<vacant.size();i++){
		
		
			//pstmt.setInt(1, rs.getInt("canid"));
			//rs2=pstmt.executeQuery();
		
		t.addCell(vacant.get(i).getCandname());
		
		t.addCell(vacant.get(i).getEmailid());
		
		t.addCell(vacant.get(i).getPost_grad());
		
		t.addCell(vacant.get(i).getMarks());
		//addCell.add(new PdfPCell(id));
		
		t.addCell(vacant.get(i).getPassed_out_year());
		
		t.addCell(vacant.get(i).getVacancy_id());
			
	}
	document.add(t);
	document.close();
	System.out.println("\tPDF download complete");
	
	


}*/


	
public void getStudentAppliedList1(List<VacancyList> vacant) throws ClassNotFoundException, FileNotFoundException, DocumentException{
		
		
				Document document = new Document(PageSize.A4, 10, 10, 10, 10);
				
				Date d=new Date();
				
				PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream("D://candidates1.pdf"));
				document.open();
				
				
				Paragraph para1 = new Paragraph("Candidates by qualification",FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLD, new CMYKColor(60, 40, 40, 100)));
				document.add(para1);
				PdfPTable t = new PdfPTable(6);
					t.setSpacingBefore(25);
					t.setSpacingAfter(25);
					PdfPCell c1 = new PdfPCell(new Phrase("Candidate Name"));		t.addCell(c1);
					PdfPCell c2 = new PdfPCell(new Phrase("Email Id"));				t.addCell(c2);
					PdfPCell c3 =  new PdfPCell(new Phrase("Graduate degree"));		t.addCell(c3);
					PdfPCell c4 = new PdfPCell(new Phrase("Graduate cgpa"));	t.addCell(c4);
					PdfPCell c5 = new PdfPCell(new Phrase("Graduate passed out year"));	t.addCell(c5);
					PdfPCell c6= new PdfPCell(new Phrase("Applied job id"));				t.addCell(c6);
					
					
					
					
					for(int i=0;i<vacant.size();i++){
						
						
							//pstmt.setInt(1, rs.getInt("canid"));
							//rs2=pstmt.executeQuery();
						
						t.addCell(vacant.get(i).getCandname());
						
						t.addCell(vacant.get(i).getEmailid());
						
						t.addCell(vacant.get(i).getGrad());
						
						t.addCell(vacant.get(i).getMarks1());
					
						t.addCell(vacant.get(i).getPassed_out_year1());
						t.addCell(vacant.get(i).getVacancy_id());
							
					}
				document.add(t);
				document.close();
				System.out.println("\tPDF download complete");
			
			
	}
	
	
	
	
	
	
}


