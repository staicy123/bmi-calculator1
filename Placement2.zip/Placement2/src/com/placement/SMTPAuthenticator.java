package com.placement;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class SMTPAuthenticator extends Authenticator {

	final String senderEmailID="stacymathew555@gmail.com";
	final String senderPassword="ilovemyfamily@143";
	
	public PasswordAuthentication getPasswordAuthentication(String senderEmailID, String senderPassword ){
		
		return new PasswordAuthentication(senderEmailID,senderPassword);
	}
	
}
