package com.placement;

import java.util.Timer;
import java.util.TimerTask;



public class VacancyPostedDate {
	Timer timer;

    public void TimerBid(long seconds) {
        timer = new Timer();
        timer.schedule(new RemindTask(), seconds*1000);
	}

    class RemindTask extends TimerTask {
    	
        public void run() {
         //  System.out.println("Start Timing");
            timer.cancel(); 
        }
}}
