package com.placement;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class CallLetterPdf {

  public static void main(String[] args) {
	  Paragraph paragraph = new Paragraph();

    Document document = new Document();

    try {
      PdfWriter.getInstance(document,
          new FileOutputStream("D://Paragraph.pdf"));

      document.open();
      document.addTitle("Call Letter");
      Font chapterFont = FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLDITALIC);
      Font paragraphFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL);
      Chunk chunk = new Chunk("Call Letter", chapterFont);
      

    //  for(int i=0; i<10; i++){
        Chunk chunk1 = new Chunk(
              "hjgdasd,ajgsdkjahsdadkjasghdwa,,,,saaaaaaa,hagtdwjawshgfda,jsfvg,jfmgfv,jf,jhf,hfv"
              + "hj,g,hhhhhhhhhhhhhhhhhhhhhhhhjfhgdggggggggggggggggf");
       
      
     // }
      paragraph.add(chunk);
      paragraph.add(chunk1);
      document.add(paragraph);
      document.close();
      System.out.println("Pdf generated");

    } catch (DocumentException e) {
      e.printStackTrace();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }

  }
}