package com.placement;

import java.io.IOException;

public interface PrimaryActionListener {

	public void register()throws IOException,ClassNotFoundException;
}
