package com.placement;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.placement.candidate.CollegeCandidate;
import com.placement.candidate.FaithCandidate;
import com.placement.candidate.OtherCandidate;
import com.placement.company.Company;
//import com.placement.placementcell.PlacementCell;
import com.placement.placementcell.PlacementCell;

public class Login {

	public static String companyLogin(List<Company> cmplist,BufferedReader br) throws IOException{
		String uname,pass;
		String companyId = null;
		int i=0;
		
		boolean status=true;
		do{
			System.out.print("Enter username : ");
			uname=br.readLine();
			System.out.print("Enter Password : ");	
			pass=br.readLine();
			
				for(i=0;i<cmplist.size();i++){
					if(uname.equals(cmplist.get(i).getEmail()) && pass.equals(cmplist.get(i).getPass())){
						System.out.println("Successfully logged in");
						companyId=cmplist.get(i).getCompid();
						status=false;
						break;
					}
					
					
				}
				
			}while(status);
		//String num1 = flist.get(i).getCanid();
		return companyId;
		
		
	}
	
	public static int fCandidateLogin(List<FaithCandidate> flist,BufferedReader br) throws IOException{
		String uname,pass;
		boolean status=true;
		int i=0;
		int num = 0 ;
		/*for(i=0;i<flist.size();i++){
			System.out.println(flist.get(i).getPlobj()+ "    " + flist.get(i).getPass());
		}*/
		
		List<String> usernameList = new ArrayList<String>();
		Map<String, Integer> map = new HashMap<String, Integer>();
		List<String> passwordList = new ArrayList<String>();
		List<Integer> idList = new ArrayList<Integer>();
		for(FaithCandidate faithCandidate: flist)
		{
			usernameList.add(faithCandidate.getCmail());
			map.put(faithCandidate.getCmail(), faithCandidate.getCanid());
			passwordList.add(faithCandidate.getPass());
			idList.add(faithCandidate.getCanid());
			
		}
		do{
			System.out.println("Enter Email : ");
			uname=br.readLine();
			System.out.println("Enter Password : ");
			//status = true;
			pass=br.readLine();
			//	for(i=0;i<flist.size();i++){
					if(usernameList.contains(uname) && passwordList.contains(pass))
							{
						System.out.println("Successfully logged in");
						num=map.get(uname);
								status = false;
						//return 
					//	break;
						//return i;
					}
				//}
					else{
						System.out.println("Incorrect username or password");
						
					
				//	break;
					}
						}while(status);
		
		//String num1 = flist.get(i).getCanid();
		//num = 
		
		return num;
		
		//}
	}
	
	
	public static int clgCandidateLogin(List<CollegeCandidate> clglist,BufferedReader br) throws IOException{
		String uname,pass;
		int num = 0;
		//int i=0;
		boolean status=true;
		
		List<String> usernameList = new ArrayList<String>();
		Map<String, Integer> map = new HashMap<String, Integer>();
		List<String> passwordList = new ArrayList<String>();
		for(CollegeCandidate colglist:clglist){
			usernameList.add(colglist.getCmail());
			passwordList.add(colglist.getPass());
			map.put(colglist.getCmail(), colglist.getCanid());
		}
		
		do{
			System.out.println("Enter username : ");
			uname=br.readLine();
			System.out.println("Enter Password : ");
			pass=br.readLine();
			//for(CollegeCandidate college : clglist){
			if(usernameList.contains(uname) && passwordList.contains(pass))
			{
		System.out.println("Successfully logged in");
				//	num = Integer.parseInt(clglist.get(i).getCanid());
					status=false;
					num=map.get(uname);
					status = false;
			//return 
		//	break;
			//return i;
		}
	//}
		else{
			System.out.println("Incorrect username or password");
			
		
	//	break;
		}
			}while(status);

//String num1 = flist.get(i).getCanid();
//num = 

return num;

		}
	
	
	public static int othCandidateLogin(List<OtherCandidate> othlist,BufferedReader br) throws IOException{
		String uname,pass;
		int num = 0;
		//int i=0;
		boolean status=true;
		
		List<String> usernameList = new ArrayList<String>();
		Map<String, Integer> map = new HashMap<String, Integer>();
		List<String> passwordList = new ArrayList<String>();
		for(OtherCandidate colglist:othlist){
			usernameList.add(colglist.getCmail());
			passwordList.add(colglist.getPass());
			map.put(colglist.getCmail(), colglist.getCanid());
		}
		
		do{
			System.out.println("Enter username : ");
			uname=br.readLine();
			System.out.println("Enter Password : ");
			pass=br.readLine();
			//for(CollegeCandidate college : clglist){
			if(usernameList.contains(uname) && passwordList.contains(pass))
			{
		System.out.println("Successfully logged in");
				//	num = Integer.parseInt(clglist.get(i).getCanid());
					status=false;
					num=map.get(uname);
					status = false;
			//return 
		//	break;
			//return i;
		}
	//}
		else{
			System.out.println("Incorrect username or password");
			
		
	//	break;
		}
			}while(status);

//String num1 = flist.get(i).getCanid();
//num = 

return num;
	}
	
	
	public static void changePassword(Object obj,BufferedReader br) throws IOException{
		//To change password
		String oldPass,newPass;
		if(obj instanceof Admin){
			Admin admin=(Admin)obj;
			for(;;){
				System.out.print("Enter old password : ");
				oldPass=br.readLine();
				if(oldPass.equals(admin.getPass())){
					System.out.println("Enter new password : ");
					newPass=br.readLine();
					admin.setPass(newPass);
					System.out.println("Password successfully changed");
					break;
				}
				else
					System.out.println("Password Incorrect. Try again.");
			}
		}
		else if(obj instanceof FaithCandidate){
			FaithCandidate fobj=(FaithCandidate)obj;
			for(;;){
				System.out.print("Enter old password : ");
				oldPass=br.readLine();
				if(oldPass.equals(fobj.getPass())){
					System.out.println("Enter new password : ");
					newPass=br.readLine();
					fobj.setPass(newPass);
					System.out.println("Password successfully changed");
					break;
				}
				else
					System.out.println("Password Incorrect. Try again.");
			}
		}
		else if(obj instanceof CollegeCandidate){
			CollegeCandidate clgobj=(CollegeCandidate)obj;
			for(;;){
				System.out.print("Enter old password : ");
				oldPass=br.readLine();
				if(oldPass.equals(clgobj.getPass())){
					System.out.println("Enter new password : ");
					newPass=br.readLine();
					clgobj.setPass(newPass);
					System.out.println("Password successfully changed");
					break;
				}
				else
					System.out.println("Password Incorrect. Try again.");
			}
		}
		else if(obj instanceof OtherCandidate){
			OtherCandidate othobj=(OtherCandidate)obj;
			for(;;){
				System.out.print("Enter old password : ");
				oldPass=br.readLine();
				if(oldPass.equals(othobj.getPass())){
					System.out.println("Enter new password : ");
					newPass=br.readLine();
					othobj.setPass(newPass);
					System.out.println("Password successfully changed");
					break;
				}
				else
					System.out.println("Password Incorrect. Try again.");
			}
		}
		else if(obj instanceof Company){
			Company cmpobj=(Company)obj;
			for(;;){
				System.out.print("Enter old password : ");
				oldPass=br.readLine();
				if(oldPass.equals(cmpobj.getPass())){
					System.out.println("Enter new password : ");
					newPass=br.readLine();
					cmpobj.setPass(newPass);
					System.out.println("Password successfully changed");
					break;
				}
				else
					System.out.println("Password Incorrect. Try again.");
			}
		}
		else if(obj instanceof PlacementCell){
			/*PlacementCell plcobj=(PlacementCell)obj;
			for(;;){
				System.out.print("Enter old password : ");
				oldPass=br.readLine();
				if(oldPass.equals(plcobj.getPass())){
					System.out.println("Enter new password : ");
					newPass=br.readLine();
					plcobj.setPass(newPass);
					System.out.println("Password successfully changed");
					break;
				}
				else
					System.out.println("Password Incorrect. Try again.");
			}*/
		}
		else{}
	}
	
	
}
