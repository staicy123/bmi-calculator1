package com.placement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class DobValidation {
	
	
	public static void main(String args[]) throws IOException{
		Validation valid = new Validation();
		BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
		boolean status;
		do{
		System.out.println("Enter dob");
		int dob= Integer.parseInt(br.readLine());
		 status = valid.validateDob1(dob);
		if(status){
			
			System.out.println("Success");
			break;
		}
		else
		{
			System.out.println("Invalid entry");
		}
		}while(status);
		
	}
	
	
	
	

}
