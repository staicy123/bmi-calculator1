package com.placement;

public class VacancyInterviewList {
	
	
	int cand_id;
	public int getCand_id() {
		return cand_id;
	}






	public void setCand_id(int cand_id) {
		this.cand_id = cand_id;
	}





	String candidate_name;
	String vacancy_id;
	String status;
	String date;
	String time;
	String recruiter_name;
	String company_name;
	
	
	
	
	
	
	
	public String getCompany_name() {
		return company_name;
	}






	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}






	public String getCandidate_name() {
		return candidate_name;
	}






	public void setCandidate_name(String candidate_name) {
		this.candidate_name = candidate_name;
	}






	public String getRecruiter_name() {
		return recruiter_name;
	}






	public void setRecruiter_name(String recruiter_name) {
		this.recruiter_name = recruiter_name;
	}






	public String getTime() {
		return time;
	}






	public void setTime(String time) {
		this.time = time;
	}






	public VacancyInterviewList() {
		super();
	}






	public VacancyInterviewList(String vacancy_id, String status, String date) {
		super();
		this.vacancy_id = vacancy_id;
		this.status = status;
		this.date = date;
	}






	public String getVacancy_id() {
		return vacancy_id;
	}






	public void setVacancy_id(String vacancy_id) {
		this.vacancy_id = vacancy_id;
	}






	public String getStatus() {
		return status;
	}






	public void setStatus(String status) {
		this.status = status;
	}






	public String getDate() {
		return date;
	}






	public void setDate(String date) {
		this.date = date;
	}
	
	
	
	

}
