package com.placement;

import java.io.BufferedReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.placement.Validation;
import com.placement.company.Vacancy;

public class AddDetails {
	
	static DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
    static Date dateobj = new Date();

	public static void addPLIDS(BufferedReader br,PlacementDatabase db1) throws IOException{
		
		String plid,batch_name,course_name,year;
		boolean yes;
		System.out.println("\nAdd Trainee Details");
		
		System.out.print("Enter PLID : ");	
		plid=br.readLine();
		System.out.print("Enter batch name : ");
		batch_name=br.readLine();
		System.out.print("Enter course name : ");	
		course_name=br.readLine();
		for(;;){
			System.out.print("Enter year of batch : "); 
			year=br.readLine();
			yes=Validation.validateYear(year);
			if(yes)
				break;
			else	System.out.println("Year not valid.Enter again");
		}
		
		
		PLIDS plid1= new PLIDS(plid,batch_name,course_name,year);
		db1.addPlid(plid1);
		
	}
	
	public static void addVacancy(String clg_id,BufferedReader br) throws IOException, ParseException{
		
		PlacementDatabase db1 = new PlacementDatabase();
		String cmail,closedate,exp,vacancy_id,no_of_passengers,vacancy_name,qual,location,status,clg_id1,opendate,open_timing,close_timing;
		boolean yes;
		clg_id1=clg_id;
		System.out.println("\nAdd Details of new vacancy");
		System.out.print("Enter vacancy id : ");	
			vacancy_id=br.readLine();
		System.out.print("Enter vacancy name : ");	
		vacancy_name=br.readLine();
		for(;;){
			System.out.print("Enter contact mail : "); 
			cmail=br.readLine();
			yes=Validation.validateEmail(cmail);
			if(yes)
				break;
			else	System.out.println("Email not valid.Enter again");
		}
		
		
		
		
			System.out.print("Enter the date you want to post the vacancy : "); 
			opendate=br.readLine();
			Date d1=df.parse(opendate);
			Date current=df.parse(df.format(dateobj));
			long diff = d1.getTime() - current.getTime();
			 int timerInterval = 3 * 60;

			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);
			long diffDs=diffDays*24*3600;
			long diffHs=diffHours*3600;
			long diffMs=diffMinutes*60;
			long diffS=diffDs+diffHs+diffMs+diffSeconds;
			//System.out.println(diffS +"seconds");
			
			VacancyPostedDate sb=new VacancyPostedDate();
			sb.TimerBid(diffS);	
			
			
		//System.out.print("Qualification for the job : ");	
		open_timing=Long.toString(diffS);
		
		
			System.out.print("Enter closing date of vacancy : "); 
			closedate=br.readLine();
			
			
			Date d2=df.parse(closedate);
			long diff2=d2.getTime()-current.getTime();
			long diffSeconds2 = diff2 / 1000 % 60;
			long diffMinutes2 = diff2 / (60 * 1000) % 60;
			long diffHours2 = diff2 / (60 * 60 * 1000) % 24;
			long diffDays2 = diff2 / (24 * 60 * 60 * 1000);
			long diffDs2=diffDays2*24*3600;
			long diffHs2=diffHours2*3600;
			long diffMs2=diffMinutes2*60;
			long diffS2=diffDs2+diffHs2+diffMs2+diffSeconds2;
			//(int)((double)System.currentTimeMillis()/1000L);
			
			//System.out.println(diffS2 +"seconds");
			VacancyLastDate eb=new VacancyLastDate();
			eb.TimerBid2(diffS2, vacancy_id);
			
			
			
		close_timing=Long.toString(diffS2);
		
		System.out.print("Qualification for the job : ");	
		qual=br.readLine();
		
		for(;;){
			System.out.print("Experience for the vacancy : "); 
			exp=br.readLine();
			yes=Validation.validateExp(exp);
			if(yes)
				break;
			else	System.out.println("Experience not a valid number .Enter again");
		}
		
		
		System.out.print("Enter job location : ");	
		location=br.readLine();
		System.out.println("Status");
		status=br.readLine();
		System.out.println("Enter the number of vacancies");
		 no_of_passengers=br.readLine();
		Vacancy vacancy = new Vacancy(vacancy_id,vacancy_name,cmail,opendate,closedate,qual,exp,location,status,clg_id1,no_of_passengers);
		db1.addVacancy(vacancy);
	}
	
}
