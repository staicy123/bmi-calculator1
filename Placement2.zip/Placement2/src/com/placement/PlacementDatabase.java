package com.placement;


	import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.placement.candidate.Candidate;
import com.placement.candidate.CollegeCandidate;
import com.placement.candidate.FaithCandidate;
import com.placement.candidate.OtherCandidate;
import com.placement.company.Company;
import com.placement.company.CompanyEmail;
import com.placement.company.Vacancy;
import com.placement.placementcell.College;
import com.placement.placementcell.CollegeCandidateDisplay;
import com.placement.placementcell.PlacementCellRegistration;
import com.placement.placementcell.PlacementOfficer;
import com.placement.placementcell.University;



	public class PlacementDatabase {
		
		public PlacementDatabase(){
			
		}
		String  JDBC_DRIVER="com.mysql.jdbc.Driver";
		String DB_URL="jdbc:mysql://localhost:3306/Placement";
		String uname="root";
		String passwd="";
		String[] username;
		String[] password;
		
		public void addUniversity(University university) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into UNIVERSITY (university_id,name) values(?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,university.getUniversity_id());
				pstmt1.setString(2,university.getUniversity_name());
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
				
		}
		
		public void addPlid(PLIDS plid) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into FAITH (plid,batch_name,course_name,year) values(?,?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,plid.getPLID());
				pstmt1.setString(2,plid.getBatch());
				pstmt1.setString(3,plid.getCrs_name());
				pstmt1.setString(4,plid.getYear());
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
				
		}
		
		
		
		public void addCourses(Courses course) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into COURSES (course_name) values(?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,course.getCourse_name());
				
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
				
		}
		
		
		
		
		
		
		
		public void addVacancyStatus(String status, String vacancyId) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="update company_vacancy set status='"+status+"' where vacancy_id='"+vacancyId+"'";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				
				//pstmt1.setString(1,vacancy.getStatus());
				
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
				
		}
		public void addVacancy(Vacancy vacancy) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into COMPANY_VACANCY (vacancy_id,vacancy_name,email,posted_date,closing_date,experience,qualification,location,status,company_id,no_of_vacancies) values(?,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,vacancy.getVac_id());
				pstmt1.setString(2,vacancy.getJob());
				pstmt1.setString(3,vacancy.getContact());
				pstmt1.setString(4,vacancy.getPosteddate());
				//pstmt1.setString(5,vacancy.getPosted_timing());
				pstmt1.setString(5,vacancy.getClosedate());
				//pstmt1.setString(7,vacancy.getClose_timing());
				pstmt1.setString(6,vacancy.getExp());
				pstmt1.setString(7,vacancy.getQual());
				pstmt1.setString(8,vacancy.getLocation());
				pstmt1.setString(9,vacancy.getStatus());
				pstmt1.setString(10,vacancy.getClg_id());
				pstmt1.setString(11,vacancy.getNo_of_vacancy());
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
				
		}
		
		
		public void addCompanyReg(Company company) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into COMPANY_REG (company_id,name,hr_name,phone,email,password) values(?,?,?,?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,company.getCompid());
				pstmt1.setString(2,company.getCompname());
				pstmt1.setString(3,company.getHr_name());
				pstmt1.setString(4,company.getPhone());
				pstmt1.setString(5,company.getEmail());
				pstmt1.setString(6,company.getPass());
				/*pstmt1.setString(7,vacancy.getLocation());
				pstmt1.setString(8,vacancy.getStatus());
*/				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
				
		}
		
		
		public void addPostGraduation(EducationalDetails edu, int candid) 
		{
			Connection conn=null;
			Statement stmt=null;
			String sql = null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				
				
				
				sql="SELECT * from educational_details where cand_id="+candid;
				ResultSet rs = stmt.executeQuery(sql);
				if(!rs.next()){
					
					
					PreparedStatement pstmt1=conn.prepareStatement("insert into educational_details (cand_id,post_graduate,cgpa,pg_passed_out_year,graduate,g_cgpa,passed_out_year) values(?,?,?,?,?,?,?)");
					 pstmt1.setInt(1,edu.getCandid());
						pstmt1.setString(2,edu.getPostgraduate());
						pstmt1.setString(3,edu.getMarks1());
						pstmt1.setString(4,edu.getPassed_out_year1());
						pstmt1.setString(5,edu.getGraduate());
						pstmt1.setString(6,edu.getMarks());
						pstmt1.setString(7,edu.getPassed_out_year());
						//pstmt1.setInt(8,candid);
						pstmt1.execute();
				}
				else
				{
					//sql=;
					//PreparedStatement pstmt1=conn.prepareStatement(sql);
					//pstmt1.setString(1,stud.getId());
					PreparedStatement pstmt1=conn.prepareStatement("update educational_details SET cand_id=?,post_graduate=?,cgpa=?,pg_passed_out_year=?,graduate=?,g_cgpa=?,passed_out_year=? where cand_id="+candid);
					pstmt1.setInt(1,edu.getCandid());
					pstmt1.setString(2,edu.getPostgraduate());
					pstmt1.setString(3,edu.getMarks1());
					pstmt1.setString(4,edu.getPassed_out_year1());
					pstmt1.setString(5,edu.getGraduate());
					pstmt1.setString(6,edu.getMarks());
					pstmt1.setString(7,edu.getPassed_out_year());
					//pstmt1.setInt(8,candid);
					pstmt1.execute();
				}
				
				
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
				
		}
		
		public void addGraduation(EducationalDetails edu) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into educational_details (cand_id,graduate,g_cgpa,passed_out_year) values(?,?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setInt(1,edu.getCandid());	
				pstmt1.setString(2,edu.getGraduate());
				pstmt1.setString(3,edu.getMarks());
				pstmt1.setString(4,edu.getPassed_out_year());
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
				
		}
		
		
		
		public void deleteUniversity(String university_id) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="delete from UNIVERSITY where university_id=?";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				
				pstmt1.setString(1,university_id);
				
				pstmt1.executeUpdate();
				
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
				
		}
		
		public void addCollege(College college) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into College (college_id,college_name,address,email,phone,university_id) values(?,?,?,?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,college.getCollege_id());
				pstmt1.setString(2,college.getCollege_name());
				pstmt1.setString(3,college.getAddress());
				pstmt1.setString(4,college.getEmail());
				pstmt1.setString(5,college.getPhone());
				pstmt1.setString(6,college.getUniversity().getUniversity_id());
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		
		public void addCandidate(CollegeCandidate candidate) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into CANDIDATE (name,email,college_id) values(?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,candidate.getName());
				pstmt1.setString(2,candidate.getCmail());
				pstmt1.setString(3,candidate.getCollege().getCollege_id());
				
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		
		
		
		public void addOtherCandidate(OtherCandidate candidate) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into CANDIDATE (name,dob,email,password,pincode,mobile) values(?,?,?,?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,candidate.getName());
				pstmt1.setString(2,candidate.getDob());
				pstmt1.setString(3,candidate.getCmail());
				pstmt1.setString(4,candidate.getPass());
				pstmt1.setString(5,candidate.getPincode());
				pstmt1.setString(6,candidate.getMob());
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		public void addInterviewDate(String date,int id,String status,String vacancy_id,String time) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="update CANDIDATE_VACANCY  SET interview_date=?,status=?,interview_time=? where cand_id=? AND vacancy_id=?";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,date);
				pstmt1.setString(2,status);
				pstmt1.setInt(4,id);
				pstmt1.setString(3,time);
				pstmt1.setString(5, vacancy_id);
				
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		
		
		
		
		
		
		
		
		public void addFaithCandidate(FaithCandidate faith) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into CANDIDATE (name,dob,email,password,pincode,mobile,plid) values(?,?,?,?,?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,faith.getName());
				pstmt1.setString(2,faith.getDob());
				pstmt1.setString(3,faith.getCmail());
				pstmt1.setString(4,faith.getPass());
				pstmt1.setString(5,faith.getPincode());
				pstmt1.setString(6,faith.getMob());
				pstmt1.setString(7,faith.getPlobj());
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		public List<FaithCandidate> getfaithCandidate() throws ClassNotFoundException
		{
			Class<?> faith = Class.forName("com.placement.candidate.FaithCandidate");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			FaithCandidate cand;
			//Student sat=null;
			//Pincode pin=null;
			List<FaithCandidate> faithlist = new ArrayList<FaithCandidate>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from CANDIDATE where college_id IS NULL";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					cand=(FaithCandidate) faith.newInstance();
					cand.setCanid(rs.getInt(1));
					cand.setName(rs.getString(2));
					cand.setDob(rs.getString(3));
					cand.setCmail(rs.getString(4));
					cand.setPass(rs.getString(5));
					cand.setPincode(rs.getString(6));
					cand.setMob(rs.getString(7));
					cand.setPlobj(rs.getString(9));
					//cand.setPlobj(rs.getString(9));
					
					
					faithlist.add(cand);
					
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return faithlist;
			
		}
		
		
		public List<OtherCandidate> getotherCandidate() throws ClassNotFoundException
		{
			Class<?> other = Class.forName("com.placement.candidate.OtherCandidate");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			OtherCandidate cand;
			//Student sat=null;
			//Pincode pin=null;
			List<OtherCandidate> faithlist = new ArrayList<OtherCandidate>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from CANDIDATE";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					cand=(OtherCandidate) other.newInstance();
					cand.setCanid(rs.getInt(1));
					cand.setName(rs.getString(2));
					cand.setDob(rs.getString(3));
					cand.setCmail(rs.getString(4));
					cand.setPass(rs.getString(5));
					cand.setPincode(rs.getString(6));
					cand.setMob(rs.getString(7));
					//cand.setPlobj(rs.getString(9));
					//cand.setPlobj(rs.getString(9));
					
					
					faithlist.add(cand);
					
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return faithlist;
			
		}
		
		
		
		
		
		public List<Vacancy> getVacancyList() throws ClassNotFoundException
		{
			Class<?> vacn = Class.forName("com.placement.company.Vacancy");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			Vacancy vacancy;
			//Student sat=null;
			//Pincode pin=null;
			List<Vacancy> vacant = new ArrayList<Vacancy>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from COMPANY_VACANCY";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					vacancy=(Vacancy) vacn.newInstance();
					vacancy.setVac_id(rs.getString(1));
					vacancy.setJob(rs.getString(2));
					vacancy.setContact(rs.getString(3));
					vacancy.setPosteddate(rs.getString(4));
					vacancy.setClosedate(rs.getString(6));
					vacancy.setExp(rs.getString(8));
					vacancy.setQual(rs.getString(9));
					vacancy.setLocation(rs.getString(10));
					vacancy.setStatus(rs.getString(11));
					//cand.setPlobj(rs.getString(9));
					
					
					vacant.add(vacancy);
					
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return vacant;
			
		}
		
		
		public List<Courses> getCourses() throws ClassNotFoundException
		{
			Class<?> cour = Class.forName("com.placement.Courses");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			Courses course;
			//Student sat=null;
			//Pincode pin=null;
			List<Courses> cor = new ArrayList<Courses>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from Courses";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					course=(Courses) cour.newInstance();
					course.setId(rs.getInt(1));
					course.setCourse_name(rs.getString(2));
					
					
					
					
					cor.add(course);
					
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return cor;
			
		}
		
		
		
		
		
		
		
		
		public void updateCandidateVacancy(int faithid,String vac_id,String status)
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into CANDIDATE_VACANCY(cand_id,vacancy_id,status) values(?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setInt(1,faithid);
				pstmt1.setString(2,vac_id);
				pstmt1.setString(3,status);	
				pstmt1.executeUpdate();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		
		
		public void addCompanyEmail(CompanyEmail company)
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into companyemailpassword(company_id,email,password) values(?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,company.getCompany_id());
				pstmt1.setString(2,company.getEmail());
				pstmt1.setString(3,company.getPassword());	
				pstmt1.executeUpdate();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		
		
		
		
		public void updateCandidate(CollegeCandidate candidate,String name) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="update CANDIDATE SET dob= ?,password=?,pincode=?,mobile=? WHERE name=?";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,candidate.getDob());
				pstmt1.setString(2,candidate.getPass());
				pstmt1.setString(3,candidate.getPincode());
				pstmt1.setString(4,candidate.getMob());
				pstmt1.setString(5,name);
				
				pstmt1.executeUpdate();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		
		
		public void updateStatus1(int id,String status) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="update CANDIDATE_VACANCY SET status=? where cand_id="+id;
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,status);
				
				
				pstmt1.executeUpdate();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		
		
		
		
		
		public void updateStatus(String status,int cand_id) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="update CANDIDATE_VACANCY status=? WHERE cand_id=?";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,status);
				pstmt1.setInt(2,cand_id);
				
				pstmt1.executeUpdate();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		
		
		
		
		
		public void placementRegister(PlacementCellRegistration place) 
		{
			Connection conn=null;
			Statement stmt=null;
			//ResultSet rs=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="insert into PLACEMENT_CELL (college_id,name,mobile,email,password) values(?,?,?,?,?)";
				PreparedStatement pstmt1=conn.prepareStatement(sql);
				//pstmt1.setString(1,stud.getId());
				pstmt1.setString(1,place.getCollege().getCollege_id());
				pstmt1.setString(2,place.getName());
				pstmt1.setString(3,place.getMobile());
				pstmt1.setString(4,place.getEmail());
				pstmt1.setString(5,place.getPassword());
				
				pstmt1.execute();
				stmt.close();
				conn.close();
				
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			
			
		}
		
		
		
		
		
		public List<University> getUniversityList() throws ClassNotFoundException
		{
			Class<?> student = Class.forName("com.placement.placementcell.University");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			University univ;
			//Student sat=null;
			//Pincode pin=null;
			List<University> university = new ArrayList<University>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from UNIVERSITY";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					univ=(University) student.newInstance();
					//pin=(Pincode) pincode.newInstance();
					univ.setUniversity_id(rs.getString(1));
					univ.setUniversity_name(rs.getString(2));
					
					//Pincode pin1 = new Pincode();
					//pin.setPincode(rs.getString(10));
					//univ.setPincode(pin);
				//	
					university.add(univ);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return university;
			
		}
		
		
		public List<VacancyList> getStudentAppliedList(String success) throws ClassNotFoundException
		{
			Class<?> vacant = Class.forName("com.placement.VacancyList");
			Class<?> cand = Class.forName("com.placement.candidate.Candidate");
			Class<?> edu = Class.forName("com.placement.EducationalDetails");
			
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			VacancyList vacancy;
			EducationalDetails ed;
			Candidate cad;
			//Student sat=null;
			//Pincode pin=null;
			List<VacancyList> vacancyList = new ArrayList<VacancyList>();
			List<Candidate> candidate = new ArrayList<Candidate>();
			List<EducationalDetails> education = new ArrayList<EducationalDetails>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			String status = "Applied";
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select c.name,c.email,e.post_graduate,e.cgpa,e.pg_passed_out_year,e.graduate,e.g_cgpa,e.passed_out_year,v.vacancy_id "
						+ " from  educational_details as e inner join candidate as c on c.id=e.cand_id inner join candidate_vacancy as v "
						+ "on c.id=v.cand_id inner join company_vacancy cv on v.vacancy_id=cv.vacancy_id where v.status ='"+status+"' "
								+ " and cv.company_id='"+success+"'";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					vacancy=(VacancyList) vacant.newInstance();
					ed=(EducationalDetails) edu.newInstance();
					cad=(Candidate) cand.newInstance();
					
					
					vacancy.setCandname(rs.getString(1));
					
					vacancy.setEmailid(rs.getString(2));
					
					vacancy.setPost_grad(rs.getString(3));
					
					vacancy.setMarks(rs.getString(4));
					
					vacancy.setPassed_out_year(rs.getString(5));
					
					vacancy.setGrad(rs.getString(6));
					
					vacancy.setMarks1(rs.getString(7));
				
					vacancy.setPassed_out_year1(rs.getString(8));
					vacancy.setVacancy_id(rs.getString(9));
					
					
					
					//Pincode pin1 = new Pincode();
					//pin.setPincode(rs.getString(10));
					//univ.setPincode(pin);
				//	
					vacancyList.add(vacancy);
					//System.out.println();
					
					
					/*for(int i=0;i<vacancyList.size();i++){
						System.out.println(vacancyList.get(i).getCandname());
					}*/
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return vacancyList;
			
		}
		
		
		
		public List<VacancyList> getStudentPostGraduationList(String PostGraduate,String success) throws ClassNotFoundException
		{
			Class<?> vacant = Class.forName("com.placement.VacancyList");
			
			
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			VacancyList vacancy;
			EducationalDetails ed;
			Candidate cad;
			//Student sat=null;
			//Pincode pin=null;
			List<VacancyList> vacancyList = new ArrayList<VacancyList>();
			
			String status = "Applied";
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select c.name,c.email,c.id,e.post_graduate,e.cgpa,e.pg_passed_out_year,e.graduate,e.g_cgpa,e.passed_out_year,v.vacancy_id "
						+ " from  educational_details as e inner join candidate as c on c.id=e.cand_id inner join candidate_vacancy as v "
						+ "on c.id=v.cand_id inner join company_vacancy cv on v.vacancy_id=cv.vacancy_id where v.status ='"+status+"' "
								+ " AND cv.company_id='"+success+"'"+ " AND e.post_graduate='"+PostGraduate+"'";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					vacancy=(VacancyList) vacant.newInstance();
					
					
					vacancy.setCandname(rs.getString(1));
					
					vacancy.setEmailid(rs.getString(2));
					vacancy.setId(rs.getInt(3));
					vacancy.setPost_grad(rs.getString(4));
					
					vacancy.setMarks(rs.getString(5));
					
					vacancy.setPassed_out_year(rs.getString(6));
					
					vacancy.setGrad(rs.getString(7));
					
					vacancy.setMarks1(rs.getString(8));
				
					vacancy.setPassed_out_year1(rs.getString(9));
					vacancy.setVacancy_id(rs.getString(10));
					
					
					
					//Pincode pin1 = new Pincode();
					//pin.setPincode(rs.getString(10));
					//univ.setPincode(pin);
				//	
					vacancyList.add(vacancy);
					//System.out.println();
					
					
					/*for(int i=0;i<vacancyList.size();i++){
						System.out.println(vacancyList.get(i).getCandname());
					}*/
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return vacancyList;
			
		}
		
		
		public List<VacancyList> getStudentGraduationList(String Graduate,String success) throws ClassNotFoundException
		{
			Class<?> vacant = Class.forName("com.placement.VacancyList");
			
			
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			VacancyList vacancy;
			EducationalDetails ed;
			Candidate cad;
			//Student sat=null;
			//Pincode pin=null;
			List<VacancyList> vacancyList = new ArrayList<VacancyList>();
			
			String status = "Applied";
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select c.name,c.email,c.id,e.graduate,e.g_cgpa,e.passed_out_year,v.vacancy_id "
							+ " from  educational_details as e inner join candidate as c on c.id=e.cand_id inner join candidate_vacancy as v "
							+ "on c.id=v.cand_id inner join company_vacancy cv on v.vacancy_id=cv.vacancy_id where v.status ='"+status+"' "
									+ " AND cv.company_id='"+success+"'"+ " AND e.graduate='"+Graduate+"'";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					vacancy=(VacancyList) vacant.newInstance();
					
					
					vacancy.setCandname(rs.getString(1));
					
					vacancy.setEmailid(rs.getString(2));
					
					vacancy.setId(rs.getInt(3));
					
					vacancy.setGrad(rs.getString(4));
					
					vacancy.setMarks1(rs.getString(5));
				
					vacancy.setPassed_out_year1(rs.getString(6));
					vacancy.setVacancy_id(rs.getString(7));
					
					
					
					//Pincode pin1 = new Pincode();
					//pin.setPincode(rs.getString(10));
					//univ.setPincode(pin);
				//	
					vacancyList.add(vacancy);
					//System.out.println();
					
					
					/*for(int i=0;i<vacancyList.size();i++){
						System.out.println(vacancyList.get(i).getCandname());
					}*/
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return vacancyList;
			
		}
		
		
		
		
		public List<PLIDS> getfaithList() throws ClassNotFoundException
		{
			Class<?> plids = Class.forName("com.placement.PLIDS");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			PLIDS plid;
			//Student sat=null;
			//Pincode pin=null;
			List<PLIDS> pl = new ArrayList<PLIDS>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from FAITH";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					plid=(PLIDS) plids.newInstance();
					//pin=(Pincode) pincode.newInstance();
					plid.setPLID(rs.getString(1));
					plid.setBatch(rs.getString(2));
					plid.setCrs_name(rs.getString(3));
					plid.setYear(rs.getString(4));
					//univ.setUniversity_name(rs.getString(2));
					
					//Pincode pin1 = new Pincode();
					//pin.setPincode(rs.getString(10));
					//univ.setPincode(pin);
				//	
					pl.add(plid);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		public List<Company> getCompanyReg() throws ClassNotFoundException
		{
			Class<?> company = Class.forName("com.placement.company.Company");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			Company comp;
			//Student sat=null;
			//Pincode pin=null;
			List<Company> cmp = new ArrayList<Company>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from COMPANY_REG";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					comp=(Company) company.newInstance();
					//pin=(Pincode) pincode.newInstance();
					comp.setCompid(rs.getString(1));
					comp.setCompname(rs.getString(2));
					comp.setHr_name(rs.getString(3));
					comp.setPhone(rs.getString(4));
					comp.setEmail(rs.getString(5));
					comp.setPass(rs.getString(6));
					
					cmp.add(comp);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return cmp;
			
		}
		
		
		
		public List<Company> getCompanyReg1(String success1) throws ClassNotFoundException
		{
			Class<?> company = Class.forName("com.placement.company.Company");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			Company comp;
			//Student sat=null;
			//Pincode pin=null;
			List<Company> cmp = new ArrayList<Company>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from COMPANY_REG where company_id='"+success1+"'";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					comp=(Company) company.newInstance();
					//pin=(Pincode) pincode.newInstance();
					comp.setCompid(rs.getString(1));
					comp.setCompname(rs.getString(2));
					comp.setHr_name(rs.getString(3));
					comp.setPhone(rs.getString(4));
					comp.setEmail(rs.getString(5));
					comp.setPass(rs.getString(6));
					
					cmp.add(comp);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return cmp;
			
		}
		
		public List<Vacancy> getSearchDetails() throws ClassNotFoundException
		{
			//Map<String,Vacancy> searchMap = new HashMap<String,Vacancy>();
			Class<?> vacn = Class.forName("com.placement.company.Vacancy");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			Vacancy vacancy;
			List<Vacancy> vacnt= new ArrayList<Vacancy>();
			
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select v.vacancy_id,v.vacancy_name,v.email,v.posted_date,v.closing_date, v.experience,v.qualification,v.location,v.no_of_vacancies,c.name,v.status from COMPANY_VACANCY as v inner join COMPANY_REG as c on v.company_id=c.company_id";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					vacancy=(Vacancy) vacn.newInstance();
					vacancy.setVac_id(rs.getString(1));
					vacancy.setJob(rs.getString(2));
					vacancy.setContact(rs.getString(3));
					vacancy.setPosteddate(rs.getString(4));
					vacancy.setClosedate(rs.getString(5));
					vacancy.setExp(rs.getString(6));
					vacancy.setQual(rs.getString(7));
					vacancy.setLocation(rs.getString(8));
					vacancy.setNo_of_vacancy(rs.getString(9));
				
					vacancy.setCompany_name(rs.getString(10));
					vacancy.setStatus(rs.getString(11));
					
					
				//	searchMap.put(rs.getString(1), vacancy);
					
					vacnt.add(vacancy);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return vacnt;
			
		}
		
		
		
		
		
		
		
		public List<CollegeCandidate> getCollegeCandidateList() throws ClassNotFoundException
		{
			Class<?> candidate = Class.forName("com.placement.candidate.CollegeCandidate");
			Class<?> college = Class.forName("com.placement.placementcell.College");
			//Class<?> pincode = Class.forName("com.placement.faith.Pincode");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			//University univ;
			//Student sat=null;
			//Pincode pin=null;
			College coll=null;
			CollegeCandidate cand=null;
			List<CollegeCandidate> colcand= new ArrayList<CollegeCandidate>();
			//List<Pincode> pincod = new ArrayList<Pincode>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from CANDIDATE where college_id IS NOT NULL";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					cand=(CollegeCandidate) candidate.newInstance();
					coll=(College) college.newInstance();
					coll.setCollege_id(rs.getString(8));
					cand.setCollege_id(coll);
					cand.setCanid(rs.getInt(1));
					cand.setName(rs.getString(2));
					cand.setDob(rs.getString(3));
					cand.setPass(rs.getString(5));
					cand.setPincode(rs.getString(6));
					cand.setMob(rs.getString(7));
					cand.setCmail(rs.getString(4));
					
					//univ.setUniversity_id(rs.getString(1));
				//	univ.setUniversity_name(rs.getString(2));
					
					//Pincode pin1 = new Pincode();
					//pin.setPincode(rs.getString(10));
					//univ.setPincode(pin);
				//	
					colcand.add(cand);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return colcand;
			
		}
		
		
		
		
		
		public List<College> getCollegeList() throws ClassNotFoundException
		{
			Class<?> college = Class.forName("com.placement.placementcell.College");
			Class<?> university = Class.forName("com.placement.placementcell.University");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			University univ;
			College coll;
			//Student sat=null;
			//Pincode pin=null;
			//List<University> univers = new ArrayList<University>();
			List<College> collg = new ArrayList<College>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from College";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					univ=(University) university.newInstance();
					coll=(College) college.newInstance();
					coll.setCollege_id(rs.getString(1));
					coll.setCollege_name(rs.getString(2));
					coll.setAddress(rs.getString(3));
					coll.setEmail(rs.getString(4));
					coll.setPhone(rs.getString(5));
					univ.setUniversity_id(rs.getString(6));
					coll.setUniversity(univ);
					//Pincode pin1 = new Pincode();
					//pin.setPincode(rs.getString(10));
					//univ.setPincode(pin);
				//	
					collg.add(coll);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return collg;
			
		}
		
	
		
		
		public List<PlacementCellRegistration> getPlacementList() throws ClassNotFoundException
		{
			Class<?> place = Class.forName("com.placement.placementcell.PlacementCellRegistration");
			Class<?> college = Class.forName("com.placement.placementcell.College");
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			PlacementCellRegistration placement;
			College coll;
			//Student sat=null;
			//Pincode pin=null;
			List<PlacementCellRegistration> pl = new ArrayList<PlacementCellRegistration>();
			List<College> collg = new ArrayList<College>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="select * from PLACEMENT_CELL";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					placement=(PlacementCellRegistration) place.newInstance();
					coll=(College) college.newInstance();
					coll.setCollege_id(rs.getString(1));
					placement.setCollege(coll);
					placement.setName(rs.getString(2));
					placement.setMobile(rs.getString(3));
					placement.setEmail(rs.getString(4));
					placement.setPassword(rs.getString(5));
					
					
					pl.add(placement);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		
		
		
		
		
		
		
		public List<PlacementOfficer> getPlacementOfficerDetail() throws ClassNotFoundException
		{
			Class<?> place = Class.forName("com.placement.placementcell.PlacementOfficer");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			PlacementOfficer placement;
			College coll;
			
			List<PlacementOfficer> pl = new ArrayList<PlacementOfficer>();
			
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="SELECT p.college_id, p.name, p.email, c.college_name FROM placement_cell AS p INNER JOIN college AS c ON c.college_id = p.college_id LIMIT 0 , 3";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					placement=(PlacementOfficer) place.newInstance();
					
					placement.setCollege_id(rs.getString(1));;
					placement.setPlacement_officer_name(rs.getString(2));
					placement.setEmail(rs.getString(3));
					placement.setCollege_name(rs.getString(4));
					
					
					
					pl.add(placement);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		
		
		
		
		public List<PlacementOfficer> getPlacementOfficerName(String college_id) throws ClassNotFoundException
		{
			Class<?> place = Class.forName("com.placement.placementcell.PlacementOfficer");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			PlacementOfficer placement;
			College coll;
			
			List<PlacementOfficer> pl = new ArrayList<PlacementOfficer>();
			
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="SELECT p.college_id, p.name, p.email, c.college_name FROM placement_cell AS p INNER JOIN college AS c ON c.college_id = p.college_id where p.college_id='"+college_id+"'";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					placement=(PlacementOfficer) place.newInstance();
					
					placement.setCollege_id(rs.getString(1));;
					placement.setPlacement_officer_name(rs.getString(2));
					placement.setEmail(rs.getString(3));
					placement.setCollege_name(rs.getString(4));
					
					
					
					pl.add(placement);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		
		public String getRecruiterEmail(String email) throws ClassNotFoundException
		{
		//	Class<?> place = Class.forName("com.placement.Company");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			
			
			String pl = null;
			
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="SELECT hr_name from company_reg where company_id='"+email+"'";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					
					
					pl=rs.getString(1);
					
					
					
					
										//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		
		
		public String getCandidateEmail(int id) throws ClassNotFoundException
		{
			//Class<?> place = Class.forName("com.placement.Company");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			
			
			String pl = null;
			
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="SELECT email from candidate where id="+id;
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					
					
					pl=rs.getString(1);
					
					
					
					
										//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		
		
		public List<VacancyInterviewList> getAppliedVacancy(int cand_id,String vacancy_id) throws ClassNotFoundException
		{
			Class<?> place = Class.forName("com.placement.VacancyInterviewList");
		//	Map<String, String> candidateVacancy = new HashMap<>();
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			
			String status="Applied";
			VacancyInterviewList vacancy = null;
			List<VacancyInterviewList> vacancyList= new ArrayList<VacancyInterviewList>();
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="SELECT cand_id,vacancy_id,status from candidate_vacancy where cand_id='"+cand_id+"'AND vacancy_id='"+vacancy_id+"'";
				
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					
					vacancy=(VacancyInterviewList) place.newInstance();
					vacancy.setCand_id(rs.getInt(1));
					vacancy.setVacancy_id(rs.getString(2));
					vacancy.setStatus(rs.getString(3));
					vacancyList.add(vacancy);
					
					
					
					
					
										//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return vacancyList;
			
		}
		
		
		
		
		public List<CollegeCandidateDisplay> getCollegeCandidateDetail(String college_id) throws ClassNotFoundException
		{
			Class<?> place = Class.forName("com.placement.placementcell.CollegeCandidateDisplay");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			CollegeCandidateDisplay placement;
			College coll;
			
			List<CollegeCandidateDisplay> pl = new ArrayList<CollegeCandidateDisplay>();
			
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql="SELECT c.name, c.email, e.post_graduate, e.cgpa, e.pg_passed_out_year, e.graduate, e.g_cgpa, e.passed_out_year FROM candidate AS c INNER JOIN educational_details AS e ON c.id = e.cand_id WHERE c.college_id ='"+college_id+"' ";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					placement=(CollegeCandidateDisplay) place.newInstance();
					
					placement.setCandidate_name(rs.getString(1));
					placement.setEmail(rs.getString(2));
					placement.setPostgraduation(rs.getString(3));
					placement.setP_marks(rs.getString(4));
					placement.setP_passed_out_year(rs.getString(5));
					placement.setGraduation(rs.getString(6));
					placement.setG_marks(rs.getString(7));
					placement.setG_passed_out_year(rs.getString(8));
				//	placement.setCollege_id(college_id);
					
					
					
					pl.add(placement);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(InstantiationException ie)
			{
				ie.printStackTrace();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		
		public List<String> getPostGraduation() throws ClassNotFoundException
		{
			Class<?> place = Class.forName("com.placement.VacancyList");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			//VacancyList placement;
			//College coll;
			
			List<String> pl = new ArrayList<String>();
			
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql=" SELECT DISTINCT post_graduate FROM educational_details ";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					
					pl.add(rs.getString(1));
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		
		public List<String> getGraduation() throws ClassNotFoundException
		{
			Class<?> place = Class.forName("com.placement.VacancyList");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			//VacancyList placement;
			//College coll;
			
			List<String> pl = new ArrayList<String>();
			
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql=" SELECT DISTINCT graduate FROM educational_details ";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					
					pl.add(rs.getString(1));
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		public List<VacancyInterviewList> getInterviewCallletter(int id) throws ClassNotFoundException
		{
			Class<?> place = Class.forName("com.placement.VacancyInterviewList");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			//VacancyList placement;
			//College coll;
			
			List<VacancyInterviewList> pl = new ArrayList<VacancyInterviewList>();
			VacancyInterviewList list=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql=" select c.name,v.vacancy_id,v.status,v.interview_date,v.interview_time,co.hr_name,co.name from candidate as c inner join candidate_vacancy as v on c.id=v.cand_id inner join company_vacancy as cv on v.vacancy_id=cv.vacancy_id inner join company_reg as co on co.company_id=cv.company_id where v.cand_id="+id;
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					list=(VacancyInterviewList) place.newInstance();
					list.setCandidate_name(rs.getString(1));
					list.setVacancy_id(rs.getString(2));
					list.setStatus(rs.getString(3));
					list.setDate(rs.getString(4));
					list.setTime(rs.getString(5));
					list.setRecruiter_name(rs.getString(6));
					list.setCompany_name(rs.getString(7));
					pl.add(list);
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		
		
		
		public String getInterviewDate(int id) throws ClassNotFoundException
		{
			//Class<?> place = Class.forName("com.placement.VacancyInterviewList");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			//VacancyList placement;
			//College coll;
			String pl=null;
			//List<VacancyInterviewList> pl = new ArrayList<VacancyInterviewList>();
			//VacancyInterviewList list=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql=" SELECT interview_date from candidate_vacancy where cand_id="+id;
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					//list=(VacancyInterviewList) place.newInstance();
					pl=(rs.getString(1));
					//pl=(rs.getString(2));
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		public String getInterviewTime(int id) throws ClassNotFoundException
		{
			//Class<?> place = Class.forName("com.placement.VacancyInterviewList");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			//VacancyList placement;
			//College coll;
			String pl=null;
			//List<VacancyInterviewList> pl = new ArrayList<VacancyInterviewList>();
			//VacancyInterviewList list=null;
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql=" SELECT interview_time from candidate_vacancy where cand_id="+id;
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					//list=(VacancyInterviewList) place.newInstance();
					pl=(rs.getString(1));
					//pl=(rs.getString(2));
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return pl;
			
		}
		
		
		
		
		
		
		
		public Map<String, String> getCompanyEmail(String success) throws ClassNotFoundException
		{
			Class<?> place = Class.forName("com.placement.company.Company");
			
			Connection conn=null;
			Statement stmt=null;
			ResultSet rs=null;
			//VacancyList placement;
			//College coll;
			
			//List<String> pl = new ArrayList<String>(); 
			Map<String, String> emailAndPassword = new HashMap<String, String>();
			
			
			
			try{
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				String sql=" SELECT email,password from companyemailpassword where company_id='"+success+"'";
				rs=stmt.executeQuery(sql);
				
				while(rs.next())
				{
					
					emailAndPassword.put(rs.getString(1), rs.getString(2));
				
					//System.out.println();
					
				}
				
				rs.close();
				stmt.close();
				conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			finally{
			
			}
			return emailAndPassword;
			
		}



}
