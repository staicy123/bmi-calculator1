package com.placement;

import java.util.*;

import com.placement.candidate.CollegeCandidate;
class SortmapKey {
 
	
	
    // This map stores unsorted values
    static Map<Object, Object> map = new HashMap<>();
 
    // Function to sort map by Key
    public static void sortbykey()
    {
        // TreeMap to store values of HashMap
        TreeMap<Object, Object> sorted = new TreeMap<>();
 
        // Copy all data from hashMap into TreeMap
        sorted.putAll(map);
 
        // Display the TreeMap which is naturally sorted
        for (Map.Entry<Object, Object> entry : sorted.entrySet()) 
            System.out.println(entry.getValue());        
    }
     
    // Driver Code
    public static void main(String args[]) throws ClassNotFoundException
    {
    	
    	PlacementDatabase db= new PlacementDatabase();
    	List<CollegeCandidate> clg=db.getCollegeCandidateList();
        // putting values in the Map
    	for(int i=0;i<clg.size();i++){
    	map.put("name", clg.get(i).getName());
    	}
       
        sortbykey();
    }
}