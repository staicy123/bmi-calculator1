package com.placement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.itextpdf.text.DocumentException;
import com.placement.candidate.CollegeCandidate;
import com.placement.candidate.FaithCandidate;
import com.placement.candidate.OtherCandidate;
import com.placement.company.Company;
import com.placement.company.CompanyEmail;
import com.placement.company.Vacancy;
import com.placement.placementcell.College;
import com.placement.placementcell.CollegeCandidateDisplay;
import com.placement.placementcell.PlacementCellRegistration;
import com.placement.placementcell.PlacementOfficer;
import com.placement.placementcell.University;

public class PlacementFreshers {
	
	
	static PlacementMain javaEmail= new PlacementMain();
	
	public void mainMethod() throws NumberFormatException, IOException, ClassNotFoundException, DocumentException, ParseException, AddressException, MessagingException{
		
		
		
		
		int opt, opt1, success;
		String[] id;
		String num;
		int faith_id,clg_id;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Admin adobj = new Admin();
		EducationalDetails edu = new EducationalDetails();
		Validation valid = new Validation();
		
		//Mail javaEmail = new Mail();

		//javaEmail.setMailServerProperties();
		//javaEmail.createEmailMessage();
		//javaEmail.sendEmail();
		
		
		

		PLIDS plobj;
		FaithCandidate fobj = new FaithCandidate();
		CollegeCandidate clgobj = new CollegeCandidate();
		OtherCandidate othobj=null;
		Company cmpobj;
		Vacancy vcobj;
		String recruiter_name = null,Company_name = null;
		Courses course = new Courses();
		PlacementCellRegistration placecell = new PlacementCellRegistration();

		College college = null;
		University university = null;
		boolean status = true;
		String format="%-30s %5d";

		List<PLIDS> pllist = new ArrayList<PLIDS>();
		
		List<University> univ = new ArrayList<University>();
		List<FaithCandidate> flist = new ArrayList<FaithCandidate>();
		List<CollegeCandidate> clglist = new ArrayList<CollegeCandidate>();
		List<OtherCandidate> othlist = new ArrayList<OtherCandidate>();
		List<Company> cmplist = new ArrayList<Company>();
		List<Vacancy> vclist = new ArrayList<Vacancy>();

		PlacementDatabase db = new PlacementDatabase();

		Class<?> dynobjects;

		System.out.println("\n\t\tFAITH PLACEMENT APP");
		System.out.println("\t\t--------------------");

		do {
			//Options for a all users
			System.out.println("\n\t1.Admin    2.Candidate    3.Company   4.Placement Cell   5.Exit\n");
			System.out.print("\tSelect one user type : ");
			opt=Integer.parseInt(br.readLine());
			switch(opt){
			
			
			
			
			
			
					case 1:
							adobj.loginAdmin(br);
							do{
									//Options for admin
									System.out.println("\n1.Add Trainees Details   2.University details  3. College details 4.Add Courses 5.Change Password   5.Exit");
								System.out.print("Select prefered operation : ");
									opt=Integer.parseInt(br.readLine());
									switch(opt){
										case 1:		//adding trainee details
												AddDetails.addPLIDS(br, db);

												do {
													System.out.println("1.Show trainee details 2.Exit");
													System.out.print("Select prefered operation : ");
													opt = Integer.parseInt(br.readLine());
													switch (opt) {
													case 1:
														pllist = db.getfaithList();
														ShowDetails.displayPLIDS(pllist);
														break;
														}
													} while (opt != 2);
												break;
										case 2:			//adding or viewing university details
												do {
													System.out.println("1.Add university details  2.Show Univeristy details  3.Delete University 4.Exit");
													System.out.print("Select prefered operation : ");
													opt = Integer.parseInt(br.readLine());
													switch (opt) {
													case 1:
														adobj.addUniversity(university, br, db);
														System.out.println("University details added successfully");
														break;

													case 2:
														List<University> univers = db.getUniversityList();
														List<University> univers1 = ShowDetails.displayUniversityList(univers);
														break;
													case 3:
														List<University> universt = db.getUniversityList();
														ShowDetails.deleteUniversityList(universt, br);
														System.out.println("deleted successfully");
														break;

																}
													} while (opt != 4);
												break;
										case 3:		//admin adding and viewing college details
												do {
												System.out.println("1.Add college details  2.Show College details 3.Exit");
												System.out.print("Select prefered operation : ");
												opt = Integer.parseInt(br.readLine());
												switch (opt) {
												case 1:

														adobj.addCollege(college, university, br, db);
														System.out.println("College details added successfully");
														break;

												case 2:
														List<College> coll = db.getCollegeList();
														ShowDetails.displayCollegeList(coll);
														break;

															}
													} while (opt != 3);
												break;
												
												
												
												
										case 4:		//admin adding course
											
											do {
												System.out.println("1.Add courses  2.Show courses  3.Exit");
												System.out.print("Select prefered operation : ");
												opt = Integer.parseInt(br.readLine());
												switch (opt) {
												case 1:
														//add courses
														course.addCourses(br,db);
														System.out.println("Courses added successfully");
														break;

												case 2:	//display courses
														List<Courses> coll = db.getCourses();
														ShowDetails.displayCourses(coll);
														break;

															}
													} while (opt != 3);
											
											
											break;
										case 5:	 		//change password
												Login.changePassword(adobj, br);
												System.out.println("Login with your new password");
												break;
										
									}
							}while(opt!=5);
					
							
							
							
							
							
					
					//Options for all candidates
					case 2:
							int canid;
							do{
									System.out.println("\n\t1.Login  2.Registration  3.Exit");
									System.out.print("\tSelect prefered operation : ");
									opt=Integer.parseInt(br.readLine());
									int opt2;
									switch(opt){
									
									
											case 1:
													System.out.println("\n\t1.Faith Candidate  2.College Candidate  3.Other Candidates  4.Exit");
													System.out.print("\tSelect one user type : ");
													opt2=Integer.parseInt(br.readLine());
													success=0;
													switch(opt2){ 
																		//faith candidate login
															case 1:
																	List<FaithCandidate> faith = db.getfaithCandidate();
																	faith_id = Login.fCandidateLogin(faith, br);
								
																				do{
																				System.out.println("1.Add Educational details 2.View vacancies 3.Download Callletter 4. Exit");
																				System.out.print("\tSelect prefered operation : ");
																				opt = Integer.parseInt(br.readLine());
																				switch (opt) {
																				case 1:		//adding faith candidate educational details 
																						edu.setFaithEducationaldetails(faith_id, br, db);
																						System.out
																								.println("Successfully Added");
																						break;
																				
																				case 2:
																					
																					boolean statuss1=false;
																					//Search vacancy
																					
																					System.out
																							.println("Enter the Job Title");
																					String designation=br.readLine();
																					System.out
																							.println("Enter the qualification");
																					String qualification=br.readLine();
																					
																					System.out
																							.println("Enter the job location prefered:");
																					String location=br.readLine();
																					
																					
																					
																					List<Vacancy> vacancy = db.getSearchDetails();
																					  
																					 System.out.printf("%-30s %-30s %-25s %-25s %-25s %-25s %-25s %-25s %-25s %-25s\n","vacancy id","Job Name","Email", "Posted Date " , "Closing Date" ,"Experience", "Qualification"," Location" ,"Company Name","No of vacancies");
																					 for(Vacancy vac: vacancy)
																						{
																				        	 
																							if(vac.getJob().contains(designation) && 
																							    (vac.getQual().contains(qualification)) && 
																							     (vac.getLocation().contains(location))
																							     && (vac.getStatus().equals("Open")))
																							{
																																											
																																
																								System.out
																										.println(vac.getVac_id()+"\t\t\t"+vac.getJob()+"\t\t\t"+vac.getContact()+"\t\t\t"+vac.getPosteddate()+"\t\t"+vac.getClosedate()+"\t"+vac.getExp()+"\t\t\t"+vac.getQual()+"\t\t\t"+vac.getLocation()+"\t\t\t\t"+vac.getCompany_name()+"\t\t\t"+vac.getNo_of_vacancy());	
																								statuss1 = true;	
																								
																								
																								
																							}
																							/*else
																							 {
																								 System.out
																										.println("No jobs available");
																								 break;
																							 }*/
																							
																						}
																					if(statuss1==false)
																					 {
																						 System.out
																								.println("No jobs available");
																						// break;
																					 }
																					
																					 
																					 
																					 
																					 
																					 
																					if(statuss1==true){
																					//showing vacancy
																					 List<Vacancy> vacancy1 = db.getSearchDetails();
																						//List<Vacancy> vacancy_id = ShowDetails.displayvacancy(vacant);
																						List<String> vacancyId = new ArrayList<String>();
																						for(Vacancy vacancy2 : vacancy1){
																							vacancyId.add(vacancy2.getVac_id());
																						}
																						
																						boolean stat=true;
																						System.out.println("Enter the vacancy id you want to apply");
																						String vac_id = br.readLine();
																						String status1 = "Applied";
																						List<VacancyInterviewList> vacancyList=db.getAppliedVacancy(faith_id,vac_id);
																						List<String> dbVacancyIds = new ArrayList<String>();
																						List<String> applystatus = new ArrayList<String>();
																						for(VacancyInterviewList vacanylist :vacancyList){
																							applystatus.add(vacanylist.getStatus());
																						}
																						
																						for(VacancyInterviewList vacancyInterviewList : vacancyList){
																							dbVacancyIds.add(vacancyInterviewList.getVacancy_id());
																						}
																						//for(int i=0;i<vacancy_id.size();i++)
																						//{
																							if(vacancyId.contains(vac_id) &&(applystatus.isEmpty())){
																							
																								db.updateCandidateVacancy(faith_id,vac_id, status1);
																								System.out.println("Successfully applied");
																								stat=true;
																							}
																							
																							
																							
																							else{
																								System.out
																										.println("Already Applied");
																								stat=false;
																							}
																					}
																							
																							
															
																						//}
																													
																						
															
																						break;
																						
																					
																					
																					
																					
																					
																					
																	
																					
																						
																				case 3:
																					
																					List<VacancyInterviewList> list =	db.getInterviewCallletter(faith_id);
																					System.out
																							.println("1.Vacancy Id     2.Status       3 Interview Date    4.Interview Time");
																					for(int i=0;i<list.size();i++){
																						System.out
																								.println(list.get(i).getVacancy_id()+"\t\t"+list.get(i).getStatus()+"\t\t"+list.get(i).getDate()+"\t\t"+list.get(i).getTime());
																					}
																					String date = null,time = null,recruiter_name1 = null,company_name = null,candidate_name = null;
																					//date=db.getInterviewDate(clg_id);
																					//time=db.getInterviewTime(clg_id);
																					
																					for(VacancyInterviewList vlist :list){
																						date=vlist.getDate();
																						time=vlist.getTime();
																						recruiter_name1=vlist.getRecruiter_name();
																						candidate_name=vlist.getCandidate_name();
																						company_name=vlist.getCompany_name();
																						
																					}
																					
																					System.out
																							.println("Do you want to confirm for the interview");
																					String selection = br.readLine();
																					String statuss="Confirmed";
																					if(selection.equals("YES")){
																						db.updateStatus1(faith_id,statuss);
																						System.out
																								.println("Job Confirmation send Successfully");
																						//break;
																						
																					}
																					System.out
																					.println("Do you want to download the call letter(YES/NO)");
																					String choice=br.readLine();
																					if(choice.equals("YES"))
																					{
																						CallLetterPdf1 cand = new CallLetterPdf1 ();
																						cand.callletter(date,time,recruiter_name1,company_name,candidate_name);
																					}
																					break;
																					
																					
																					//break;
				
																					
				
																}
																				}while(opt!=4);
																				break;			
				
															case 2:
																//college candidate login
																	List<CollegeCandidate> clg = db.getCollegeCandidateList();
																	
																	clg_id=Login.clgCandidateLogin(clg, br);
																	do{
																			System.out.println("1.Add Educational details 2.View vacancies  3.View Callletter   4. Exit");
																			System.out.print("\tSelect prefered operation : ");
																			opt = Integer.parseInt(br.readLine());
																			switch (opt) 
																			{
																				//adding college candidate educational details 
																				case 1:
																				edu.setFaithEducationaldetails(clg_id, br, db);
																				System.out
																						.println("Successfully Added");
																				break;
					
															
																				case 2:
																						// showing vacancies
																					//Search vacancy
																					System.out
																							.println("Enter the Job Title");
																					String designation=br.readLine();
																					System.out
																							.println("Enter the qualification");
																					String qualification=br.readLine();
																					
																					System.out
																							.println("Enter the job location prefered:");
																					String location=br.readLine();
																					
																					boolean statuss1=false;
																					
																					List<Vacancy> vacancy = db.getSearchDetails();
																					  
																					 System.out.printf("%-30s %-30s %-25s %-25s   %-25s %-25s %-25s %-25s %-25s %-25s\n","vacancy id","Job Name","Email", "Posted Date " , "Closing Date" ,"Experience", "Qualification"," Location" ,"Company Name","No of Vacancies");
																					 for(Vacancy vac: vacancy)
																						{
																				        	 
																							if(vac.getJob().contains(designation) && 
																							    (vac.getQual().contains(qualification)) && 
																							     (vac.getLocation().contains(location))
																							     && (vac.getStatus().equals("Open")))
																							{
																																											
																																
																								System.out
																										.println(vac.getVac_id()+"\t\t\t"+vac.getJob()+"\t\t\t"+vac.getContact()+"\t\t\t"+vac.getPosteddate()+"\t\t"+vac.getClosedate()+"\t"+vac.getExp()+"\t\t\t"+vac.getQual()+"\t\t\t"+vac.getLocation()+"\t\t\t\t"+vac.getCompany_name()+"\t\t\t"+vac.getNo_of_vacancy());	
																								statuss1 = true;	
																								
																								
																								
																							}
																							
																						}
																					 if(statuss1==false)
																					 {
																						 System.out
																								.println("No jobs available");
																					 }
																					 
																					 
																					 
																					 
																					 
																					if(statuss1==true){
																					//showing vacancy
																					 List<Vacancy> vacancy1 = db.getSearchDetails();
																						
																						List<String> vacancyId = new ArrayList<String>();
																						
																						for(Vacancy vacancy2 : vacancy1){
																							vacancyId.add(vacancy2.getVac_id());
																						}
																						
																					
																						
																						boolean stat=true;
																						System.out.println("Enter the vacancy id you want to apply");
																						String vac_id = br.readLine();
																						String status1 = "Applied";
																						List<VacancyInterviewList> vacancyList=db.getAppliedVacancy(clg_id,vac_id);
																						List<String> applystatus = new ArrayList<String>();
																						for(VacancyInterviewList vacanylist :vacancyList){
																							applystatus.add(vacanylist.getStatus());
																						}
																						
																						
																						
																						List<String> dbVacancyIds = new ArrayList<String>();
																						for(VacancyInterviewList vacancyInterviewList : vacancyList){
																							dbVacancyIds.add(vacancyInterviewList.getVacancy_id());
																						}
																						
																							if(vacancyId.contains(vac_id) && (applystatus.isEmpty())){
																							
																								db.updateCandidateVacancy(clg_id,vac_id, status1);
																								System.out.println("Successfully applied");
																								stat=true;
																							}
																							
																							
																							
																							else{
																								System.out
																										.println("Already Applied");
																							}
																							
																					}
															
																					
																													
																						
															
																						break;
																				
																				
																				case 3:
																					
																				List<VacancyInterviewList> list =	db.getInterviewCallletter(clg_id);
																					System.out
																							.println("1.Vacancy Id     2.Status         3 Interview Date    4.Interview Time");
																					for(int i=0;i<list.size();i++){
																						System.out
																								.println(list.get(i).getVacancy_id()+"\t\t"+list.get(i).getStatus()+"\t\t"+list.get(i).getDate()+"\t\t"+list.get(i).getTime());
																					}
																					String date = null,time = null,recruiter_name1 = null,company_name = null,candidate_name = null;
																				
																					
																					for(VacancyInterviewList vlist :list){
																						date=vlist.getDate();
																						time=vlist.getTime();
																						recruiter_name1=vlist.getRecruiter_name();
																						candidate_name=vlist.getCandidate_name();
																						company_name=vlist.getCompany_name();
																						
																					}
																					
																					System.out
																							.println("Do you want to confirm for the interview");
																					String selection = br.readLine();
																					String statuss="Confirmed";
																					if(selection.equals("YES")){
																						db.updateStatus1(clg_id,statuss);
																						System.out
																								.println("Job Confirmation send Successfully");
																						//break;
																						
																					}
																					System.out
																					.println("Do you want to download the call letter(YES/NO)");
																					String choice=br.readLine();
																					if(choice.equals("YES"))
																					{
																						CallLetterPdf1 cand = new CallLetterPdf1 ();
																						cand.callletter(date,time,recruiter_name1,company_name,candidate_name);
																					}
																					
																					break;
					
																			}
																	}while(opt!=4);
																	break;
															case 3:
																	//othercandidate login
																	List<OtherCandidate> other = db.getotherCandidate();
																	success=Login.othCandidateLogin(other, br);
																	
																	System.out.println("1.Add Educational details 2.View vacancies  3.View Call letter 4. Exit");
																	System.out.print("\tSelect prefered operation : ");
																	opt = Integer.parseInt(br.readLine());
																	switch (opt) 
																	{
																				//showing other candidate educational details
																		case 1:
																		edu.setFaithEducationaldetails(success, br, db);
																		break;
			
													
																		case 2:
																				//showing vacancy
																		List<Vacancy> vacant = db.getVacancyList();
																		List<Vacancy> vacancy_id = ShowDetails.displayvacancy(vacant);
														
												
																		System.out.println("Enter the vacancy id you want to apply");
																		String vac_id = br.readLine();
																		String status1 = "Applied";
																		for(int i=0;i<vacancy_id.size();i++)
																		{
																			if (vac_id.equals(vacancy_id.get(i).getVac_id())) 
																				{
																	
																					db.updateCandidateVacancy(success,vac_id, status1);
																				}
														
																			}
																		System.out.println("Successfully applied");
														
																		break;
																		
																		
																		
																		case 3:
																			
																			List<VacancyInterviewList> list =	db.getInterviewCallletter(success);
																				System.out
																						.println("1.Vacancy Id      2.Status       3 Interview Date    4.Interview Time");
																				for(int i=0;i<list.size();i++){
																					System.out
																							.println(list.get(i).getVacancy_id()+"\t\t"+list.get(i).getStatus()+"\t\t"+list.get(i).getDate()+"\t\t"+list.get(i).getTime());
																				}
																				String date = null,time = null,recruiter_name1 = null,company_name = null,candidate_name = null;
																				
																				
																				for(VacancyInterviewList vlist :list){
																					date=vlist.getDate();
																					time=vlist.getTime();
																					recruiter_name1=vlist.getRecruiter_name();
																					candidate_name=vlist.getCandidate_name();
																					company_name=vlist.getCompany_name();
																					
																				}
																				
																				System.out
																						.println("Do you want to confirm for the interview");
																				String selection = br.readLine();
																				String statuss="Confirmed";
																				if(selection.equals("YES")){
																					db.updateStatus1(success,statuss);
																					System.out
																							.println("Job Confirmation send Successfully");
																					//break;
																					
																				}
																				System.out
																				.println("Do you want to download the call letter(YES/NO)");
																				String choice=br.readLine();
																				if(choice.equals("YES"))
																				{
																					CallLetterPdf1 cand = new CallLetterPdf1 ();
																					cand.callletter(date,time,recruiter_name1,company_name,candidate_name);
																				}
																				break;
				
			
																	}
																	
																	
																	
																	
																	break;
																	
																	
																	
																	
																	
																	
															case 4:break;
															default:System.out.println("Invalid option");
													}
												
													break; 
												
													
											case 2:
													System.out.println("\n\t1.Faith Candidate  2.College Candidate  3.Other Candidates  4.Exit");
													System.out.print("\tSelect one user type : ");
													opt2=Integer.parseInt(br.readLine());
													//success=0;
													switch(opt2){	//faith candidate registration
															case 1:	int suc = 0;
																			String email,plid;

																	List<PLIDS> pl = db.getfaithList();
																	do {
																		System.out.println("Enter plid");
																		plid = br.readLine();
																		for (int i = 0; i < pl.size(); i++) {
																			if (plid.equals(pl.get(i).getPLID())) {

																			fobj.register(plid);
																			status = true;
																			break;
																				}
																			}
								
																			if(status==false) {
																			System.out.println("Enter valid plid or you have already registered");
																				
																				break;
																					}
							
																						// }

																			} while (status == false);

																		break;
																		
																		//college candidate registration
															case 2:
																	System.out.println("College Candidate Registration form");

																	clgobj.register();
																	System.out
																			.println("Registration Completed");

																		break;
																		
																		
																		//candidate registration
															case 3:
																
																	System.out.println("Candidate Registration form");
																	othobj.register();
																	
																		break;
															case 4:break;
															default:System.out.println("Invalid option");
													}
													break;
													
													
											case 3:break;
											default: System.out.println("Invalid option");
									}
							}while(opt!=3);
							break;
							
							
							
							
							
							
							
							
					//Options for a company
					case 3:
							int compid=0;
							do{
								System.out.println("\n\t1.Login  2.Registration  3.Exit");
								System.out.print("\tSelect prefered operation : ");
								opt=Integer.parseInt(br.readLine());
								switch(opt){
										case 1:
												
												List<Company> compy = db.getCompanyReg();
												String success1 = Login.companyLogin(compy, br);
												do{
												System.out.println("\n\t1.Add vacancy 2. View list of applied students 3.View College Placement List  4.Download the list of students  5.Add email and password for sending call letter 6.Exit");
												System.out.print("\tSelect prefered operation : ");
												opt = Integer.parseInt(br.readLine());
													switch (opt) {
														//company to add vacancy
														case 1:
															AddDetails.addVacancy(success1, br);
															System.out.println("vacancy added");
														break;

														case 2:
															
															 // view the list of students who have applied for the job
															List<VacancyList> vacant1 = db.getStudentAppliedList(success1);
															do{
															System.out.println("Select the degree based on which you want to view the vacancy");
															System.out.println("1.Post graduate  2.Graduate 3 Exit");
															System.out.print("\tSelect prefered operation : ");
															opt = Integer.parseInt(br.readLine());
															switch(opt){
															
															
															//selection for postgraduate degree
															case 1:
																
																List<String> postGraduateList = db.getPostGraduation();
																System.out
																		.println("Enter the post graduate degree");
																
															String postGraduate=br.readLine();
															Map<String, VacancyList> postGraduateMap = new HashMap<String, VacancyList>();
															System.out.format("%-30s %-40s %-20s   %-20s %-20s %-20s\n","Candidate name","Email","Post graduate","C.G.P.A","Passed out year","Vacancy ID");
														//	System.out.println("1.Candidate name          2.Email                 3.Post graduate        4 C.G.P.A    5. Passed out year");
															if(postGraduateList.contains(postGraduate)){
															for(VacancyList vacancy : vacant1){
																if(vacancy.getPost_grad().equalsIgnoreCase(postGraduate)){
																	
																	postGraduateMap.put(vacancy.getEmailid(), vacancy);
																	System.out.println(vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getPost_grad()+"\t\t\t"+vacancy.getMarks()+"\t\t\t"+vacancy.getPassed_out_year()+"\t\t\t"+vacancy.getVacancy_id());
																	}
																	}
																}
																
																
																System.out
																		.println("Sort the details based on  1.C.G.P.A 2.Passed out year ");
																opt=Integer.parseInt(br.readLine());
																switch(opt)
																{
																	
																		case 1:
																
																
																
																
																				List<VacancyList> vacantt=db.getStudentPostGraduationList(postGraduate,success1);
																				
																	
																				Collections.sort(vacantt,new CgpaSort());
																				System.out.format("%-20s %-30s %-40s %-20s   %-20s %-20s %-20s\n","Candidate ID","Candidate name","Email","Post graduate","C.G.P.A","Passed out year","Vacancy ID");
																				//System.out.println(" 1.CandidateId   2.Candidate name         3.Email            4.Postgraduate          5 C.G.P.A        6. Passed out year ");
																				
																				List<String> emailList3 = new ArrayList<String>();
																				List<Integer> candidate_Id = new ArrayList<Integer>();
																				List<String> vacancy_Id = new ArrayList<String>();
																				for(VacancyList vacancy : vacantt){
																
																
															
																					System.out.println(vacancy.getId()+"\t\t\t"+vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getPost_grad()+"\t\t\t"+vacancy.getMarks()+"\t\t\t"+vacancy.getPassed_out_year()+"\t\t\t"+vacancy.getVacancy_id());
																					emailList3.add(vacancy.getEmailid());
																					candidate_Id.add(vacancy.getId());
																					vacancy_Id.add(vacancy.getVacancy_id());
																					
																				}
																				
																				List<Company> comp2=db.getCompanyReg1(success1);
																				for(int i=0;i<comp2.size();i++)
																				{
																					recruiter_name=comp2.get(i).getHr_name();
																					Company_name=comp2.get(i).getCompname();
																					
																				}
																				String selection3;
																				System.out
																						.println("Do you want to send call letter for the above candidate:(YES/NO)");
																						selection3=br.readLine();
																				
																						String vacancy_id = null;
																				if(selection3.equals("YES")){
																					
																					System.out
																							.println("Enter the candidate id you want to send the call letter");
																					int cand_name=Integer.parseInt(br.readLine());
																					
																					
																					
																					
																					System.out
																							.println("Enter the vacancy id");
																					String vacnt_id=br.readLine();
																				
																						
																						if((candidate_Id.contains(cand_name)) && (vacancy_Id.contains(vacnt_id))){
																							
																							System.out
																							.println("1.Send Call letter to Student Profile    2.Send Call letter to Mail");
																					opt=Integer.parseInt(br.readLine());
																					switch(opt){
																					
																					case 1:
																						
																						
																						String date,time;
																						boolean date_status,time_status;
																						for(;;){
																							System.out
																									.println("Enter the date you want to schedule the interview");
																							 date=br.readLine();
																							 date_status=valid.validateDate(date);
																							 if(date_status)
																							 {
																								 break;
																							 }
																							 else{
																								 System.out
																										.println("Enter Valid Date");
																							 }
																						}
																						System.out
																								.println("Enter the time");
																						time=br.readLine();
																						
																						
																						
																						
																						
																						
																							String Status="Callletter";
																							db.addInterviewDate(date,cand_name,Status,vacnt_id,time);
																							System.out
																									.println("Call letter send successfully");
																						
																							
																						
																						break;
																						
																						
																					case 2:
																						
																						
																						String date1,time1;
																						boolean date_status1,time_status1;
																						String email=db.getCandidateEmail(cand_name);
																						for(;;){
																							System.out
																									.println("Enter the date you want to schedule the interview");
																							 date1=br.readLine();
																							 date_status1=valid.validateDate(date1);
																							 if(date_status1)
																							 {
																								 break;
																							 }
																							 else{
																								 System.out
																										.println("Enter Valid Date");
																							 }
																						}
																						time=br.readLine();
																						time_status=valid.timeValidation(time);
																						
																						
																						
																							String Status1="Callletter";
																							db.addInterviewDate(date1,cand_name,Status1,vacnt_id,time);
																						
																						
																						
																						
																						
																						
																						
																						
																						
																						Map<String, String> map = db.getCompanyEmail(success1);
																						javaEmail.setMailServerProperties();
																						javaEmail.createEmailMessage2(email,recruiter_name,Company_name,date1,time);
																					
																						javaEmail.sendEmail(map);
																						break;
																					
																					}
																							
																						}
																						
																					//}
																				
																				
																				
																				break;
																				}
																				
																				break;
																
																
																			case 2:
																				List<VacancyList> vacantts=db.getStudentPostGraduationList(postGraduate,success1);
																				
																	
																				Collections.sort(vacantts,new PassedOutYearSort());
																				System.out.format("%-20s %-30s %-40s %-20s   %-20s %-20s %-20s\n","Candidate ID","Candidate name","Email","Post graduate","C.G.P.A","Passed out year","Vacancy ID");
																				//System.out.println(" 1.CandidateId     2.Candidate name             3.Email                     4.Graduate            5 C.G.P.A          6. Passed out year ");
																				
																				List<String> emailList4 = new ArrayList<String>();
																				List<Integer> candidate_Id4 = new ArrayList<Integer>();
																				List<String> vacancy_Id1 = new ArrayList<String>();
																				for(VacancyList vacancy : vacantts){
																
																
															
																					System.out.println(vacancy.getId()+"\t\t\t"+vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getPost_grad()+"\t\t\t"+vacancy.getMarks()+"\t\t\t"+vacancy.getPassed_out_year()+"\t\t\t"+vacancy.getVacancy_id());
																					emailList4.add(vacancy.getEmailid());
																					candidate_Id4.add(vacancy.getId());
																					vacancy_Id1.add(vacancy.getVacancy_id());
																					
																				}
																				
																				List<Company> comp4=db.getCompanyReg1(success1);
																				for(int i=0;i<comp4.size();i++)
																				{
																					recruiter_name=comp4.get(i).getHr_name();
																					Company_name=comp4.get(i).getCompname();
																					
																				}
																				String selection4;
																				System.out
																						.println("Do you want to send call letter for the above candidate:(YES/NO)");
																						selection3=br.readLine();
																				
																					String vacancy_id1 = null;	
																				if(selection3.equals("YES")){
																					
																					System.out
																							.println("Enter the candidate id you want to send the call letter");
																					int cand_name=Integer.parseInt(br.readLine());
																					
																					System.out
																							.println("Enter the vacancy id");
																					String vacnt_id=br.readLine();
																					
																						
																						if((candidate_Id4.contains(cand_name)) && (vacancy_Id1.contains(vacnt_id))){
																							
																							System.out
																							.println("1.Send Call letter to Student Profile    2.Send Call letter to Mail");
																					opt=Integer.parseInt(br.readLine());
																					switch(opt){
																					
																					case 1:
																						
																						String date,time;
																						boolean date_status,time_status;
																						for(;;){
																							System.out
																									.println("Enter the date you want to schedule the interview");
																							 date=br.readLine();
																							 date_status=valid.validateDate(date);
																							 if(date_status)
																							 {
																								 break;
																							 }
																							 else{
																								 System.out
																										.println("Enter Valid Date");
																							 }
																						}
																						System.out
																						.println("Enter the time");
																				time=br.readLine();
																						
																						
																						
																							String Status="Callletter";
																							db.addInterviewDate(date,cand_name,Status,vacnt_id,date);
																							System.out
																							.println("Call letter send successfully");
																							
																						
																						break;
																						
																						
																					case 2:
																						String date1,time1;
																						boolean date_status1,time_status1;
																						String email=db.getCandidateEmail(cand_name);
																						for(;;){
																							System.out
																									.println("Enter the date you want to schedule the interview");
																							 date1=br.readLine();
																							 date_status1=valid.validateDate(date1);
																							 if(date_status1)
																							 {
																								 break;
																							 }
																							 else{
																								 System.out
																										.println("Enter Valid Date");
																							 }
																						}
																						System.out
																						.println("Enter the time");
																						time1=br.readLine();
																						
																						
																							String Status1="Callletter";
																							db.addInterviewDate(date1,cand_name,Status1,vacnt_id,time1);
																						
																						
																						
																						
																						
																						
																						
																						
																						
																						Map<String, String> map = db.getCompanyEmail(success1);
																						javaEmail.setMailServerProperties();
																						javaEmail.createEmailMessage2(email,recruiter_name,Company_name,date1,time1);
																						//query select email, emailpasswrd from table where compId = success1
																						javaEmail.sendEmail(map);
																						break;
																					
																					}
																							
																						}
																						
																				//	}
																				
																				
																				
																				break;
																				}
																}
																
																
															break;
															//selection for graduate degree
															case 2:
																System.out
																.println("Enter the graduate degree");
																List<String> GraduateList = db.getGraduation();
																
																String Graduate=br.readLine();
																Map<String, VacancyList> GraduateMap = new HashMap<String, VacancyList>();
																System.out.format("%-30s %-40s %-20s   %-20s %-20s %-20s\n","Candidate name","Email","Graduate","C.G.P.A","Passed out year","Vacancy ID");
																//System.out.println("1.candidate name    2.Email     3. Graduate  4.C.G.P.A    5. Passed out year");
																if(GraduateList.contains(Graduate)){
																for(VacancyList vacancy : vacant1){
																	if(vacancy.getGrad().equalsIgnoreCase(Graduate)){
																		
																		GraduateMap.put(vacancy.getEmailid(), vacancy);
																		System.out.println(vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getGrad()+"\t\t\t"+vacancy.getMarks1()+"\t\t\t"+vacancy.getPassed_out_year1()+"\t\t\t"+vacancy.getVacancy_id());
																	}
																}
																}
																	
																
																		System.out
																				.println("Sort the details based on  1.C.G.P.A 2.Passed out year ");
																		System.out
																				.println("Enter preffered option");
																			opt=Integer.parseInt(br.readLine());
																				switch(opt)
																					{
															
																						case 1:
														
														
														
														
																							List<VacancyList> vacany=db.getStudentGraduationList(Graduate, success1);
																	
															
																							Collections.sort(vacany,new CgpaSort1());
																							System.out.format("%-20s %-30s %-40s %-20s   %-20s %-20s %-20s\n","Candidate ID","Candidate name","Email","Graduate","C.G.P.A","Passed out year","Vacancy ID");
																						//	System.out.println(" 1.CandidateId   2.Candidate name         3.Email            4.Graduate          5 C.G.P.A        6. Passed out year ");
																							
																							List<String> emailList3 = new ArrayList<String>();
																							List<Integer> candidate_Id = new ArrayList<Integer>();
																							List<String> vacancy_Id = new ArrayList<String>();
																							for(VacancyList vacancy : vacany){
																			
																			
																		
																								System.out.println(vacancy.getId()+"\t\t\t"+vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getGrad()+"\t\t\t"+vacancy.getMarks1()+"\t\t\t"+vacancy.getPassed_out_year1()+"\t\t\t"+vacancy.getVacancy_id());
																								emailList3.add(vacancy.getEmailid());
																								candidate_Id.add(vacancy.getId());
																								vacancy_Id.add(vacancy.getVacancy_id());
																								
																							}
																							
																							List<Company> comp2=db.getCompanyReg1(success1);
																							for(int i=0;i<comp2.size();i++)
																							{
																								recruiter_name=comp2.get(i).getHr_name();
																								Company_name=comp2.get(i).getCompname();
																								
																							}
																							String selection3;
																							System.out
																									.println("Do you want to send call letter for the above candidate:(YES/NO)");
																									selection3=br.readLine();
																							
																							String vacancy_id = null;
																							if(selection3.equals("YES")){
																								
																								System.out
																										.println("Enter the candidate id you want to send the call letter");
																								int cand_name=Integer.parseInt(br.readLine());
																								for(String vacan: vacancy_Id){
																									 vacancy_id=vacan;
																								}
																								System.out
																										.println("Enter the vacancy id");
																								String vacnt_id=br.readLine();
																								//for(int name: candidate_Id){
																									
																									if((candidate_Id.contains(cand_name)) && ( vacancy_Id.contains(vacnt_id))){
																										
																										System.out
																										.println("1.Send Call letter to Student Profile    2.Send Call letter to Mail");
																								opt=Integer.parseInt(br.readLine());
																								switch(opt){
																								
																								case 1:
																									
																									String date,time;
																									boolean date_status,time_status;
																								//	for(;;){
																										System.out
																												.println("Enter the date you want to schedule the interview");
																										 date=br.readLine();
																										// date_status=valid.validateDate(date);
																										// if(date_status)
																										// {
																										//	 break;
																										// }
																									//	 else{
																										//	 System.out
																										//			.println("Enter Valid Date");
																										// }
																									//}
																									System.out
																									.println("Enter the time");
																							time=br.readLine();
																									
																									
																										String Status="Callletter";
																										db.addInterviewDate(date,cand_name,Status,vacnt_id,time);
																										System.out
																										.println("Call letter send successfully");
																										
																									
																									break;
																									
																									
																								case 2:
																									String date1,time1;
																									boolean date_status1,time_status1;
																									String email=db.getCandidateEmail(cand_name);
																									for(;;){
																										System.out
																												.println("Enter the date you want to schedule the interview");
																										 date1=br.readLine();
																										 date_status1=valid.validateDate(date1);
																										 if(date_status1)
																										 {
																											 break;
																										 }
																										 else{
																											 System.out
																													.println("Enter Valid Date");
																										 }
																									}
																									/*for(;;){*/
																									System.out
																											.println("Enter the time");
																									time1=br.readLine();
																									/*time_status1=valid.timeValidation(time1);
																									if(time_status1)
																										break;
																									else{
																										System.out
																												.println("Invalid date");
																									}
																									}*/
																									
																									
																									
																										String Status1="Callletter";
																										db.addInterviewDate(date1,cand_name,Status1,vacnt_id,time1);
																									
																									
																									
																									
																									
																									
																									
																									
																									
																									Map<String, String> map = db.getCompanyEmail(success1);
																									javaEmail.setMailServerProperties();
																									javaEmail.createEmailMessage2(email,recruiter_name,Company_name,date1,time1);
																									
																									javaEmail.sendEmail(map);
																									break;
																								
																								}
																										
																									}
																									
																							//	}
																							
																							
																							
																							break;
																							}
																							
																								break;
														
														
																						case 2:
																							List<VacancyList> vacany1=db.getStudentGraduationList(Graduate, success1);
																		
															
																							Collections.sort(vacany1,new PassedOutYearSort1());
																							System.out.format("%-30s %-40s %-20s   %-20s %-20s %-20s\n","Candidate name","Email","Graduate","C.G.P.A","Passed out year","Vacancy ID");
																						//	System.out.println(" 1.CandidateId        2.Candidate name             3.Email              4.Graduate          5 C.G.P.A        6. Passed out year ");
																		
																							List<String> emailListt = new ArrayList<String>();
																							List<Integer> candidate_Id1 = new ArrayList<Integer>();
																							List<String> vacancy_Id2= new ArrayList<String>();
																							for(VacancyList vacancy : vacany1){
																			
																			
																		
																								System.out.println(vacancy.getId()+"\t\t\t"+vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getGrad()+"\t\t\t"+vacancy.getMarks1()+"\t\t\t"+vacancy.getPassed_out_year1()+"\t\t\t"+vacancy.getVacancy_id());
																								emailListt.add(vacancy.getEmailid());
																								candidate_Id1.add(vacancy.getId());
																								vacancy_Id2.add(vacancy.getVacancy_id());
																								
																							}
																							
																							List<Company> compp2=db.getCompanyReg1(success1);
																							for(int i=0;i<compp2.size();i++)
																							{
																								recruiter_name=compp2.get(i).getHr_name();
																								Company_name=compp2.get(i).getCompname();
																								
																							}
																							String selection4;
																							System.out
																									.println("Do you want to send call letter for the above candidate:(YES/NO)");
																									selection4=br.readLine();
																							
																							String vacancy_id2 = null;
																							if(selection4.equals("YES")){
																								
																								System.out
																										.println("Enter the candidate id you want to send the call letter");
																								int cand_name=Integer.parseInt(br.readLine());
																								for(String vacan: vacancy_Id2){
																									 vacancy_id=vacan;
																								}
																								System.out
																										.println("Enter the vacancy id");
																								String vacnt_id=br.readLine();
																								//for(int name: candidate_Id1){
																									
																									if((candidate_Id1.contains(cand_name)) && (vacancy_Id2.contains(vacnt_id))){
																										
																										System.out
																										.println("1.Send Call letter to Student Profile    2.Send Call letter to Mail");
																								opt=Integer.parseInt(br.readLine());
																								switch(opt){
																								
																								case 1:
																									
																									String date,time;
																									boolean date_status,time_status;
																									for(;;){
																										System.out
																												.println("Enter the date you want to schedule the interview");
																										 date=br.readLine();
																										 date_status=valid.validateDate(date);
																										 if(date_status)
																										 {
																											 break;
																										 }
																										 else{
																											 System.out
																													.println("Enter Valid Date");
																										 }
																									}
																								
																									System.out
																											.println("Enter the time");
																									time=br.readLine();
																									
																									
																									
																									
																										String Status="Callletter";
																										db.addInterviewDate(date,cand_name,Status,vacnt_id,time);
																										System.out
																										.println("Call letter send successfully");
																										
																									
																									break;
																									
																									
																								case 2:
																									String date1,time1;
																									boolean date_status1,time_status1;
																									String email=db.getCandidateEmail(cand_name);
																									for(;;){
																										System.out
																												.println("Enter the date you want to schedule the interview");
																										 date1=br.readLine();
																										 date_status1=valid.validateDate(date1);
																										 if(date_status1)
																										 {
																											 break;
																										 }
																										 else{
																											 System.out
																													.println("Enter Valid Date");
																										 }
																									}
																									//for(;;){
																									System.out
																											.println("Enter the time");
																									time1=br.readLine();
																									//time_status1=valid.timeValidation(time1);
																									/*if(time_status1)
																										break;
																									else{
																										System.out
																												.println("Invalid date");
																									}
																									}*/
																									
																									
																									
																										String Status1="Callletter";
																										db.addInterviewDate(date1,cand_name,Status1,vacnt_id,time1);
																									
																									
																									
																									
																									
																									
																									
																									
																									
																									Map<String, String> map = db.getCompanyEmail(success1);
																									javaEmail.setMailServerProperties();
																									javaEmail.createEmailMessage2(email,recruiter_name,Company_name,date1,time1);
																									//query select email, emailpasswrd from table where compId = success1
																									javaEmail.sendEmail(map);
																									break;
																								
																								}
																										
																									}
																									
																							//	}
																							
																							
																							
																							break;
																							}
															
																							break;
																					}
														
																
																
																
															
																
																
																break;
															
															
															}
															}while(opt!=3);
															break;
															
																
															
															
																	//view placement officer list
														case 3:
															
																String choice,colg_id = null;;
															List <String> numm = new ArrayList<String>();
															
																		List<PlacementOfficer> officer=db.getPlacementOfficerDetail();
																		 numm=ShowDetails.displayPlacementOfficerList(officer);
																		System.out
																				.println("Enter the college id whose college student list you want to view");
																		String num1=br.readLine();
																		for(String college_id : numm)
																		if(num1.equals(college_id)){
																			
																			List<CollegeCandidateDisplay> coll=db.getCollegeCandidateDetail(num1);
																			ShowDetails.displayCollegeCandidateList(coll);
																			
																			System.out.println("Do you want to contact the placement officers YES/NO");
																			choice=br.readLine();
																			
																			if(choice.equals("YES") && (num1.equals(college_id))){
																				List<PlacementOfficer> officer1=db.getPlacementOfficerDetail();
																				String email= ShowDetails.displayPlacementOfficerList1(officer1,num1);
																				Map<String, String> map1 = db.getCompanyEmail(success1);
																				String name=db.getRecruiterEmail(success1);
																					javaEmail.setMailServerProperties();
																					javaEmail.createEmailMessage(email,name);
																					
																					javaEmail.sendEmail(map1);
																				 
																			}
																			else
																				break;
																			
																		}
																		
															
															
															
															break;
															
														case 4:
															//generate list based on qualification
															List<VacancyList> vacant2 = db.getStudentAppliedList(success1);
															do{
															System.out.println("Select the degree based on which you want to genearte the list");
															System.out.println("1.Post graduate  2.Graduate 3 Exit");
															System.out.print("\tSelect prefered operation : ");
															opt = Integer.parseInt(br.readLine());
															switch(opt){
															
															
															//selection for postgraduate degree
															case 1:
																
																List<String> postGraduateList = db.getPostGraduation();
																System.out
																		.println("Enter the post graduate degree");
																
															String postGraduate=br.readLine();
															Map<String, VacancyList> postGraduateMap = new HashMap<String, VacancyList>();
															System.out.format("%-30s %-40s %-20s   %-20s %-20s\n","Candidate name","Email","Post graduate","C.G.P.A","Passed out year");
															//System.out.println("1.candidate name    2.Email    3.Post graduate    4 C.G.P.A    5. Passed out year  6. Graduate  7.C.G.P.A    8. Passed out year");
															if(postGraduateList.contains(postGraduate)){
															for(VacancyList vacancy : vacant2){
																if(vacancy.getPost_grad().equalsIgnoreCase(postGraduate)){
																	
																	postGraduateMap.put(vacancy.getEmailid(), vacancy);
																	System.out.println(vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getPost_grad()+"\t\t\t"+vacancy.getMarks()+"\t\t\t"+vacancy.getPassed_out_year());
																	}
																	}
																}
																
																
																System.out
																		.println("Sort the details based on  1.C.G.P.A 2.Passed out year ");
																opt=Integer.parseInt(br.readLine());
																switch(opt)
																{
																	
																		case 1:
																
																
																
																
																				List<VacancyList> vacantt=db.getStudentPostGraduationList(postGraduate,success1);
																				//VacancyList vacancy;
																	
																				Collections.sort(vacantt,new CgpaSort());
																				System.out.format("%-30s %-40s %-20s   %-20s %-20s\n","Candidate name","Email","Post graduate","C.G.P.A","Passed out year");
																				//System.out.println("1.candidate name    2.Email    3.Post graduate    4 C.G.P.A    5. Passed out year ");
																				List<String> emailList1 = new ArrayList<String>();
																				for(VacancyList vacancy : vacantt){
																		
																			
																			//postGraduateMap.put(vacancy.getEmailid(), vacancy);
																				System.out.println(vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getPost_grad()+"\t\t\t"+vacancy.getMarks()+"\t\t\t"+vacancy.getPassed_out_year());
																				emailList1.add(vacancy.getEmailid());
																				
																				}
																
																	
																	
																
																				CandidateByQualification1 candidate= new CandidateByQualification1();
																				candidate.getStudentAppliedList(vacantt);
																				break;
																
																
																			case 2:
																				List<VacancyList> vacantts=db.getStudentPostGraduationList(postGraduate,success1);
																				
																	
																				Collections.sort(vacantts,new PassedOutYearSort());
																				System.out.format("%-30s %-40s %-20s   %-20s %-20s\n","Candidate name","Email","Post graduate","C.G.P.A","Passed out year");
																				//System.out.println("1.candidate name    2.Email    3.Post graduate    4 C.G.P.A    5. Passed out year ");
																				
																				
																				for(VacancyList vacancy : vacantts){
																					
																					
																					//postGraduateMap.put(vacancy.getEmailid(), vacancy);
																						System.out.println(vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getPost_grad()+"\t\t\t"+vacancy.getMarks()+"\t\t\t"+vacancy.getPassed_out_year());
																						}
																				
																				CandidateByQualification1 candidate1= new CandidateByQualification1();
																				candidate1.getStudentAppliedList(vacantts);
																				
																	
																			break;
																}
																
																
															break;
															//selection for graduate degree
															case 2:
																System.out
																.println("Enter the graduate degree");
																List<String> GraduateList = db.getGraduation();
																
																String Graduate=br.readLine();
																Map<String, VacancyList> GraduateMap = new HashMap<String, VacancyList>();
																System.out.format("%-30s %-40s %-20s   %-20s %-20s\n","Candidate name","Email"," Graduate","C.G.P.A","Passed out year");
															//	System.out.println("1.candidate name    2.Email     3. Graduate  4.C.G.P.A    5. Passed out year");
																if(GraduateList.contains(Graduate)){
																for(VacancyList vacancy : vacant2){
																	if(vacancy.getGrad().equalsIgnoreCase(Graduate)){
																		
																		GraduateMap.put(vacancy.getEmailid(), vacancy);
																		System.out.println(vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getGrad()+"\t\t\t"+vacancy.getMarks1()+"\t\t\t"+vacancy.getPassed_out_year1());
																	}
																}
																}
																	
																
																		System.out
																				.println("Sort the details based on  1.C.G.P.A 2.Passed out year ");
																		System.out
																				.println("Enter preffered option");
																			opt=Integer.parseInt(br.readLine());
																				switch(opt)
																					{
															
																						case 1:
														
														
														
														
																							List<VacancyList> vacany=db.getStudentGraduationList(Graduate, success1);
																	
															
																							Collections.sort(vacany,new CgpaSort1());
																							System.out.format("%-30s %-40s %-20s   %-20s %-20s\n","Candidate name","Email"," Graduate","C.G.P.A","Passed out year");
															
																						//	System.out.println("1.Candidate name         2.Email                  3.Graduate          4 C.G.P.A        5. Passed out year ");
															
																							for(VacancyList vacancy : vacany){
																
																	
																
																								System.out.println(vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getGrad()+"\t\t\t"+vacancy.getMarks1()+"\t\t\t"+vacancy.getPassed_out_year1());
																							}
														
															
															
														
																		
																		
																								CandidateByQualification1 candidate1= new CandidateByQualification1();
																								candidate1.getStudentAppliedList1(vacany);
																								break;
														
														
																						case 2:
																							List<VacancyList> vacany1=db.getStudentGraduationList(Graduate, success1);
																		
															
																							Collections.sort(vacany1,new PassedOutYearSort1());
																							System.out.format("%-30s %-40s %-20s   %-20s %-20s\n","Candidate name","Email","Graduate","C.G.P.A","Passed out year");
																		
																						//	System.out.println("1.Candidate name         2.Email                  3.Graduate          4 C.G.P.A        5. Passed out year ");
																		
																		
																							for(VacancyList vacancy : vacany1){
																			
																			
																		
																								System.out.println(vacancy.getCandname()+"\t\t\t"+vacancy.getEmailid()+"\t\t\t"+vacancy.getGrad()+"\t\t\t"+vacancy.getMarks1()+"\t\t\t"+vacancy.getPassed_out_year1());
																							}
																		
																							CandidateByQualification1 candidatee= new CandidateByQualification1();
																							candidatee.getStudentAppliedList(vacany1);
																		
															
																							break;
																					}
														
																
																
																
															
																
																
																break;
															
															
															}
															}while(opt!=3);
															break;
															
															
														case 5:	
															CompanyEmail email= new CompanyEmail();
															email.EmailandPassword(br,db,success1);
															break;
															
													}
												}while(opt<=5);
													break;
												
											//company registration	
										case 2:
												Company cmpobj1 = new Company();
												cmpobj1.register();
						
												break;
										
										
								}
							}while(opt!=3);
							break;
							
							
							
						
							
							
							
					
					//Options for a Placement cell
					case 4:
							int opt2=0;
							do{
									System.out.println("1.Login      2.Register    3.Exit");
									System.out.print("Enter your choice : ");
									opt2=Integer.parseInt(br.readLine());
									switch(opt2){
									
									
											case 1:	     //placement cell login
														List<PlacementCellRegistration> place = db.getPlacementList();
														String colg_id = null,email_id = null;
														id = placecell.login(place, br);
														for(int i=0;i<id.length;i++){
															colg_id=id[0];
															email_id=id[1];
														}
														
														do {
															System.out.println("1.Add Student details  2. View Recruiter List  3.Exit");
															opt = Integer.parseInt(br.readLine());
	
														switch (opt) {
													case 1:// Add candidate
														clgobj.addCandidate(colg_id);
														break;
														
														
													case 2:
														String choice,choice1,email1,company_id,officer_name = null,college_name = null;
														//View Recruiter list and contact them
														List<Company> company=db.getCompanyReg();
														ShowDetails.displayRecruiterDetails(company);
														System.out
																.println("Do you want to contact the company? YES/NO");
														choice=br.readLine();
														
														if(choice.equals("YES")){
														
														System.out
																.println("Enter the company id to send the mail");
														choice1= br.readLine();
														List<PlacementOfficer> placementList=db.getPlacementOfficerName(colg_id);
														for(int i=0;i<placementList.size();i++){
															officer_name=placementList.get(i).getPlacement_officer_name();
															college_name=placementList.get(i).getCollege_name();
														}
														for(int i=0;i<company.size();i++)
														{
															if(choice1.equals(company.get(i).getCompid()))
															{
																email1= company.get(i).getEmail();
																
																javaEmail.setMailServerProperties();
																javaEmail.createEmailMessage1(email1,officer_name,college_name);
																
																javaEmail.sendEmail1(email_id);
															 
																
																
																
																
																
															}
														}
														}
														else
															break;
														
														break;
	
														}
														
													
	
														} while (opt != 3);
												break;
												
													
								
											case 2:	
													System.out.println("***************Placement officer registration form**************");
														placecell.register();
														System.out.println("Registration completed successfully");

										break;
											case 3:
													break;
											default:	System.out.println("Wrong option");
									}
							}while(opt2!=3);
							break;
					
					
					
							
							
					
					
					case 5:
							//exit
							break;
					default:System.out.println("Invalid option");
			}
		}while(opt!=5);
	}
	
	}


class CgpaSort implements Comparator<VacancyList>
{
	public int compare(VacancyList VacancyArrayList, VacancyList Marksortobj){
		
		return Marksortobj.getMarks().compareTo(VacancyArrayList.getMarks());
	}
}
class PassedOutYearSort implements Comparator<VacancyList>
{
	public int compare(VacancyList VacancyArrayList, VacancyList Yearsortobj){
		
		return Yearsortobj.getPassed_out_year().compareTo(VacancyArrayList.getPassed_out_year());
	}
}
class CgpaSort1 implements Comparator<VacancyList>
{
	public int compare(VacancyList VacancyArrayList, VacancyList Marksortobj){
		
		return Marksortobj.getMarks1().compareTo(VacancyArrayList.getMarks1());
	}
}
class PassedOutYearSort1 implements Comparator<VacancyList>
{
	public int compare(VacancyList VacancyArrayList, VacancyList Yearsortobj){
		
		return Yearsortobj.getPassed_out_year1().compareTo(VacancyArrayList.getPassed_out_year1());
	}
}


