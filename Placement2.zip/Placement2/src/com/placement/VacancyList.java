package com.placement;



import com.placement.candidate.Candidate;

public class VacancyList implements Comparable<VacancyList> {
	int id;
	String candname;
	String emailid;
	String post_grad;
	String marks;
	String passed_out_year;
	String grad;
	String marks1;
	String passed_out_year1;
	String vacancy_id;
	String status;
	
	
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCandname() {
		return candname;
	}
	public void setCandname(String candname) {
		this.candname = candname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPost_grad() {
		return post_grad;
	}
	public void setPost_grad(String post_grad) {
		this.post_grad = post_grad;
	}
	public String getMarks() {
		return marks;
	}
	public void setMarks(String marks) {
		this.marks = marks;
	}
	public String getPassed_out_year() {
		return passed_out_year;
	}
	public void setPassed_out_year(String passed_out_year) {
		this.passed_out_year = passed_out_year;
	}
	public String getGrad() {
		return grad;
	}
	public void setGrad(String grad) {
		this.grad = grad;
	}
	public String getMarks1() {
		return marks1;
	}
	public void setMarks1(String marks1) {
		this.marks1 = marks1;
	}
	public String getPassed_out_year1() {
		return passed_out_year1;
	}
	public void setPassed_out_year1(String passed_out_year1) {
		this.passed_out_year1 = passed_out_year1;
	}
	public String getVacancy_id() {
		return vacancy_id;
	}
	public void setVacancy_id(String vacancy_id) {
		this.vacancy_id = vacancy_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public int compareTo(VacancyList arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
