package com.placement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;



//import com.placement.faith.Validation;
import com.placement.placementcell.College;
import com.placement.placementcell.University;

public final class Admin{

	private String user="admin";
	private String pass="admin";
	Validation valid = new Validation(); 
	PlacementDatabase db=new PlacementDatabase();
	
	public Admin() {
		super();
	}

	public Admin(String user, String pass) {
		super();
		this.user = user;
		this.pass = pass;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public void loginAdmin(BufferedReader br) throws IOException{
		String uname,pass;
		for(;;){
			System.out.print("Enter username : ");
			uname=br.readLine();
			System.out.print("Enter Password : ");
			pass=br.readLine();
			if(uname.equals(this.user)&& pass.equals(this.pass)){
				System.out.println("Successfully logged in");
				return;
			}
			else
				System.out.println("Wrong username or password. Enter Correctly.");
		}
	}
	
	public void addCollege(College college,University university,BufferedReader br, PlacementDatabase db) throws IOException, ClassNotFoundException{
		
			String college_id,college_name,address,email,phone,university_id;
			boolean college_status,name_status,address_status,email_status,phone_status,university_status,status1 = false;
			
			for(;;){
				
				System.out.println("Enter college_id");
				college_id=br.readLine();
				college_status=valid.memberidValidation(college_id);
				if(college_status)
					break;
				else
				{
					System.out.println("Wrong input");
				}
			}
			
			for(;;){
				
			
				System.out.println("Enter college name");
				college_name=br.readLine();
				name_status=valid.validateLetters(college_name);
				if(name_status)
					break;
				else
				{
					System.out.println("Wrong input");
				}
			}
			for(;;){
				System.out.println("Enter address");
				address=br.readLine();
				address_status=valid.validateLetters(address);
				if(address_status)
					break;
				else
				{
					System.out.println("Wrong input");
				}
			}
			for(;;){
				System.out.println("Enter email");
				email=br.readLine();
				email_status=valid.validateEmail(email);
				if(email_status)
					break;
				else
				{
					System.out.println("Wrong input");
				}
			}
			for(;;){
				System.out.println("Enter phone number");
				phone=br.readLine();
				phone_status=valid.validatePhoneNumber(phone);
				if(phone_status)
					break;
				else
				{
					System.out.println("Wrong input");
				}
				
			}
			
			
			List<University> col = db.getUniversityList();
			System.out.println("University id\t\tUniversity name    ");
			//for(;;){
					for(int i=0 ; i<col.size(); i++){
					
					System.out.println(col.get(i).getUniversity_id()+"\t"+col.get(i).getUniversity_name());
					}
					do{
						System.out.println("Enter University id");
						university_id= br.readLine();
						for(int i=0 ; i<col.size(); i++){
							if(university_id.equals(col.get(i).getUniversity_id())){
								status1=true;
								break;
								}
						}
							if(status1==false){
								System.out.println("Enter valid id from the above list");
								//status1=false;
								break;
							
							}
						
					}while(status1!=true);
			
			university = new University(university_id);
			college= new College(college_id,college_name,address,email,phone,university);
			db.addCollege(college);
			
			
	}
	
	public void addUniversity(University university,BufferedReader br, PlacementDatabase db) throws IOException{
		
		String university_id,name; boolean id_status,name_status;
		for(;;){
			System.out.println("Enter university_id");
			university_id=br.readLine();
			id_status=valid.memberidValidation(university_id);
			if(id_status)
				break;
			else
			{
				System.out.println("Wrong input");
			}
			
			
		}
		for(;;){
			System.out.println("Enter University name");
			name=br.readLine();
			name_status=valid.validateLetters(name);
			if(name_status)
				break;
			else
			{
				System.out.println("Wrong input");
			}
			
		}
		university = new University(university_id,name);
		db.addUniversity(university);
		
	}

}
