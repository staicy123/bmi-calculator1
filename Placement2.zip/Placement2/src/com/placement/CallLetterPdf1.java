package com.placement;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class CallLetterPdf1 {

	
	
	

	
	  public void callletter(String date,String time,String recruiter,String company,String candidate)  {

	    Document document = new Document();

	    try {
	      PdfWriter.getInstance(document,
	          new FileOutputStream("D://Callletter"));

	      document.open();
	      Paragraph paragraph = new Paragraph();
	      
	      Font chapterFont = FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLDITALIC);
	      Font paragraphFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL);
	      Chunk chunk = new Chunk("Call Letter\n\n", chapterFont);
	      //for(int i=0; i<10; i++){
	        Chunk chunk1 = new Chunk(
	              "Dear "+candidate+",\n "
				+ "You are hereby notified in response to your application for the vacant position applied for the company "+company+". "
				+ "A written test is being held on "+date+"  at "+time+". "
				+ " Kindly come along with a blue ball point & a blue marker."
				+ "You are advised to reach at least 15 minutes before the decided time.\n"
				+ "Wish you best of luck\n"
				+ ""+recruiter+"\n"
				+ "HR Manager" );
	        paragraph.add(chunk);
	        paragraph.add(chunk1);
	    //  }
	      
	      document.add(paragraph);
	      document.close();
	  	System.out.println("\tPDF download complete");

	    } catch (DocumentException e) {
	      e.printStackTrace();
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    }

	  }
	
}
