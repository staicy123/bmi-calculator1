package com.placement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import ch.qos.logback.core.util.TimeUtil;



public class VacancyDate {
	 static DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
    static Date dateobj = new Date();
		
		
	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the start time");
		String st=br.readLine();
		Date d1=df.parse(st);
		Date current=df.parse(df.format(dateobj));
		long diff = d1.getTime() - current.getTime();
		 int timerInterval = 3 * 60;

		long diffSeconds = diff / 1000 % 60;
		long diffMinutes = diff / (60 * 1000) % 60;
		long diffHours = diff / (60 * 60 * 1000) % 24;
		long diffDays = diff / (24 * 60 * 60 * 1000);
		long diffDs=diffDays*24*3600;
		long diffHs=diffHours*3600;
		long diffMs=diffMinutes*60;
		long diffS=diffDs+diffHs+diffMs+diffSeconds;
		System.out.println(diffSeconds +" seconds");
		
		VacancyPostedDate sb=new VacancyPostedDate();
		sb.TimerBid(diffS);
		System.out.println("enter the end time");
		String et=br.readLine();
		Date d2=df.parse(et);
		long diff2=d2.getTime()-current.getTime();
		long diffSeconds2 = diff2 / 1000 % 60;
		long diffMinutes2 = diff2 / (60 * 1000) % 60;
		long diffHours2 = diff2 / (60 * 60 * 1000) % 24;
		long diffDays2 = diff2 / (24 * 60 * 60 * 1000);
		long diffDs2=diffDays2*24*3600;
		long diffHs2=diffHours2*3600;
		long diffMs2=diffMinutes2*60;
		long diffS2=diffDs2+diffHs2+diffMs2+diffSeconds2;
		long minutes = TimeUnit.MILLISECONDS.toMinutes(diffS2);
		//(int)((double)System.currentTimeMillis()/1000L);
		
		System.out.println(diffSeconds2 +" seconds" +diffMinutes2+ " minutes");
		VacancyLastDate eb=new VacancyLastDate();
		eb.TimerBid2(diffS2);
		
	}

}
