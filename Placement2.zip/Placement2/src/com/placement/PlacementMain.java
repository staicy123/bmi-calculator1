package com.placement;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.itextpdf.text.Document;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.OutputStream;
import java.util.Date;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
//import com.itextpdf.text.List.x;

import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.DocumentException;
import com.placement.candidate.CollegeCandidate;
import com.placement.candidate.FaithCandidate;
import com.placement.candidate.OtherCandidate;
import com.placement.company.Company;
import com.placement.company.CompanyEmail;
import com.placement.company.Vacancy;
import com.placement.placementcell.College;
import com.placement.placementcell.CollegeCandidateDisplay;
import com.placement.placementcell.PlacementCellRegistration;
import com.placement.placementcell.PlacementOfficer;
import com.placement.placementcell.University;


public class PlacementMain {
	
	
	Properties emailProperties;
	Session mailSession;
	MimeMessage emailMessage;
	static PlacementMain javaEmail= new PlacementMain();

	public static void main(String[] args) throws NumberFormatException,
			IOException, ClassNotFoundException, InstantiationException,
			IllegalAccessException, FileNotFoundException, AddressException, MessagingException, DocumentException, ParseException {
		// TODO Auto-generated method stub
		PlacementFreshers place = new PlacementFreshers();
		place.mainMethod();

}
	public void setMailServerProperties() {

		String emailPort = "587";//gmail's smtp port

		emailProperties = System.getProperties();
		emailProperties.put("mail.smtp.port", emailPort);
		emailProperties.put("mail.smtp.auth", "true");
		emailProperties.put("mail.smtp.starttls.enable", "true");

	}

	public void createEmailMessage2(String emailList,String recruiter_name,String company_name,String date,String time) throws AddressException,
			MessagingException {
		
		
	
		String emailSubject = "Call Letter";
		String emailBody = "Dear Applicant,\n "
				+ "You are hereby notified in response to your application for the vacant position applied for the company "+company_name+"."
				+ "A written test is being held on "+date+" at "+time+"."
				+ " Kindly come along with a blue ball point & a blue marker."
				+ "You are advised to reach at least 15 minutes before the decided time.\n"
				+ "Wish you best of luck\n"
				+ ""+recruiter_name+"\n"
				+ "HR Department\n";

		mailSession = Session.getDefaultInstance(emailProperties, null);
		emailMessage = new MimeMessage(mailSession);

		
		
		//for(String email : emailList){
			
			emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(emailList));
		//}

		emailMessage.setSubject(emailSubject);
		emailMessage.setContent(emailBody, "text/html");//for a html email
		//emailMessage.setText(emailBody);// for a text email

	}
	
	
	public void createEmailMessage(String email,String name) throws AddressException,
	MessagingException {


		
		String emailSubject = "Placement Opportunity";
		String emailBody = "Respected sir\n On concerning above subject, "
				+ "I "+name+" from faith infotech industries standing as board member of this multinational company request"
				+ " you to let us have opportunity of recruit your final year students in our company"
				+ " as per your placement formats. Reply will be highly appreciated regarding this topic. \nThank you.\nYours;\n"+name+"";

		mailSession = Session.getDefaultInstance(emailProperties, null);
		emailMessage = new MimeMessage(mailSession);


		emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(email));


		emailMessage.setSubject(emailSubject);
		emailMessage.setContent(emailBody, "text/html");//for a html email
//emailMessage.setText(emailBody);// for a text email

}
	
	
	
	
	public void createEmailMessage1(String email,String officer_name,String college_name) throws AddressException,
	MessagingException {


		
		String emailSubject = "Invitation for campus recruitment";
		String emailBody = "I take this opportunity to introduce myself, This is "+officer_name+","
				+ " Sr. Placement Officer of "+college_name+". "
				+ "As a part of our continuous strives to bring the top companies to the college premises,"
				+ " We would like to request you to consider the possibilities of conducting your recruitment drive for B.Tech"
				+ " ( CS/IT, EC, EE, EIC, Mechanical, Electrical ), B.Pharmacy, M.Pharmacy, MBA, MCA and "
				+ "Polytechnic diploma (Mechanical, Electrical, Civil, Automobile) 2018 Batch."
				+ " We want to join hands with your esteemed organization and help our students"
				+ " to achieve a better career in your company."
				+ " We will provide you quality entrant from required branches.\n"
				+ "We look forward for receiving your positive response.\n"
				+ "Thanks.\n"
				+ "Warm Regards,\n"
				+ ""+officer_name+"\n"
				+ "Training & Placement Officer\n";

		mailSession = Session.getDefaultInstance(emailProperties, null);
		emailMessage = new MimeMessage(mailSession);


		emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(email));


		emailMessage.setSubject(emailSubject);
		emailMessage.setContent(emailBody, "text/html");//for a html email
//emailMessage.setText(emailBody);// for a text email

}

	
	
	
	

	public void sendEmail(Map<String, String> map) throws AddressException, MessagingException {

		Map.Entry<String, String> entry = map.entrySet().iterator().next();
		String email = entry.getKey();
		String password = entry.getValue();
		
		String emailHost = "smtp.gmail.com";

		Transport transport = mailSession.getTransport("smtp");

		transport.connect(emailHost, email, password);
		transport.sendMessage(emailMessage, emailMessage.getAllRecipients());
		transport.close();
		System.out.println("Email sent successfully.");
	}
	public void sendEmail1(String email) throws AddressException, MessagingException {

		String emailHost = "smtp.gmail.com";
		String fromUser = email;//just the id alone without @gmail.com
		String fromUserEmailPassword = "ilovemyfamily@143";

		Transport transport = mailSession.getTransport("smtp");

		transport.connect(emailHost, fromUser, fromUserEmailPassword);
		transport.sendMessage(emailMessage, emailMessage.getAllRecipients());
		transport.close();
		System.out.println("Email sent successfully.");
	}
	
	
	

}
