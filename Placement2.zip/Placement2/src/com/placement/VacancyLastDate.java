package com.placement;

import java.util.Timer;
import java.util.TimerTask;

import com.placement.company.Vacancy;


public class VacancyLastDate {
	Timer timer;
	private String vacancyId;
	public void TimerBid2(long seconds, String vacancyId) {
		this.vacancyId = vacancyId;
        timer = new Timer();
        timer.schedule(new RemindTask(), seconds*1000);
	}

    class RemindTask extends TimerTask {
    	
        public void run() {
          //  System.out.println("End timing");
            PlacementDatabase placementdb = new PlacementDatabase();
            String status = "Closed";
           placementdb.addVacancyStatus(status, vacancyId);
            timer.cancel(); 
        }
       
}
}
