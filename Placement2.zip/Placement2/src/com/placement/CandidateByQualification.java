package com.placement;

//package com.pdfs;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.*;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.util.Date;
import java.util.List;

//import dbfunctions.DataBaseFunctions;

public class CandidateByQualification {

	public void getStudentAppliedList(String graduate,String success) throws ClassNotFoundException{
		
		String  JDBC_DRIVER="com.mysql.jdbc.Driver";
		String DB_URL="jdbc:mysql://localhost:3306/Placement";
		String uname="root";
		String passwd="";
		String[] username;
		String[] password;
		
			String sql,path;
			PreparedStatement pstmt=null;
			PlacementDatabase db=new PlacementDatabase();
			ResultSet rs=null,rs2=null;
			Statement stmt=null;
			Connection conn=null;
			try{
				
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				Document document = new Document(PageSize.A4, 10, 10, 10, 10);
				//G://FaithPlacementApp/GeneratedPDFs/sample.pdf
				Date d=new Date();
				//path="G://FaithPlacementApp/GeneratedPDFs/"+d+".pdf";
				PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream("D://candidates.pdf"));
				document.open();
				String status = "Applied";
				
				Paragraph para1 = new Paragraph("Candidates by qualification",FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLD, new CMYKColor(60, 40, 40, 100)));
				document.add(para1);
				PdfPTable t = new PdfPTable(9);
					t.setSpacingBefore(25);
					t.setSpacingAfter(25);
					PdfPCell c1 = new PdfPCell(new Phrase("Candidate Name"));		t.addCell(c1);
					PdfPCell c2 = new PdfPCell(new Phrase("Email Id"));				t.addCell(c2);
					PdfPCell c3 = new PdfPCell(new Phrase("Post graduate degree"));		t.addCell(c3);
					PdfPCell c4 = new PdfPCell(new Phrase("Post graduate cgpa"));	t.addCell(c4);
					PdfPCell c5 = new PdfPCell(new Phrase("Post graduate passed out year"));				t.addCell(c5);
					PdfPCell c6 = new PdfPCell(new Phrase("Graduate degree"));		t.addCell(c6);
					PdfPCell c7 = new PdfPCell(new Phrase("Graduate cgpa"));	t.addCell(c7);
					PdfPCell c8 = new PdfPCell(new Phrase("Graduate passed out year"));				t.addCell(c8);
					PdfPCell c9 = new PdfPCell(new Phrase("Applied job id"));				t.addCell(c9);
					
					
					sql="select c.name,c.email,e.post_graduate,e.cgpa,e.pg_passed_out_year,e.graduate,e.g_cgpa,e.passed_out_year,v.vacancy_id "
							+ " from  educational_details as e inner join candidate as c on c.id=e.cand_id inner join candidate_vacancy as v "
							+ "on c.id=v.cand_id inner join company_vacancy cv on v.vacancy_id=cv.vacancy_id where v.status ='"+status+"' "
									+ " AND cv.company_id='"+success+"'"+ " AND e.post_graduate='"+graduate+"'";
				
					    rs=stmt.executeQuery(sql);
				while(rs.next()){
					
					
						//pstmt.setInt(1, rs.getInt("canid"));
						//rs2=pstmt.executeQuery();
					
					t.addCell(rs.getString(1));
					
					t.addCell(rs.getString(2));
					
					t.addCell(rs.getString(3));
					
					t.addCell(rs.getString(4));
					
					t.addCell(rs.getString(5));
					
					t.addCell(rs.getString(6));
					
					t.addCell(rs.getString(7));
				
					t.addCell(rs.getString(8));
					t.addCell(rs.getString(9));
						
				}
				document.add(t);
				document.close();
				System.out.println("\tPDF download complete");
			}catch(SQLException ex){
					ex.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
	
	
	
public void getStudentAppliedList1(String graduate,String success) throws ClassNotFoundException{
		
		String  JDBC_DRIVER="com.mysql.jdbc.Driver";
		String DB_URL="jdbc:mysql://localhost:3306/Placement";
		String uname="root";
		String passwd="";
		String[] username;
		String[] password;
		
			String sql,path;
			PreparedStatement pstmt=null;
			PlacementDatabase db=new PlacementDatabase();
			ResultSet rs=null,rs2=null;
			Statement stmt=null;
			Connection conn=null;
			try{
				
				Class.forName(JDBC_DRIVER);
				conn=DriverManager.getConnection(DB_URL,uname,passwd);
				stmt=conn.createStatement();
				Document document = new Document(PageSize.A4, 10, 10, 10, 10);
				//G://FaithPlacementApp/GeneratedPDFs/sample.pdf
				Date d=new Date();
				//path="G://FaithPlacementApp/GeneratedPDFs/"+d+".pdf";
				PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream("D://candidates1.pdf"));
				document.open();
				String status = "Applied";
				
				Paragraph para1 = new Paragraph("Candidates by qualification",FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLD, new CMYKColor(60, 40, 40, 100)));
				document.add(para1);
				PdfPTable t = new PdfPTable(6);
					t.setSpacingBefore(25);
					t.setSpacingAfter(25);
					PdfPCell c1 = new PdfPCell(new Phrase("Candidate Name"));		t.addCell(c1);
					PdfPCell c2 = new PdfPCell(new Phrase("Email Id"));				t.addCell(c2);
					PdfPCell c3 =  new PdfPCell(new Phrase("Graduate degree"));		t.addCell(c3);
					PdfPCell c4 = new PdfPCell(new Phrase("Graduate cgpa"));	t.addCell(c4);
					PdfPCell c5 = new PdfPCell(new Phrase("Graduate passed out year"));	t.addCell(c5);
					PdfPCell c6= new PdfPCell(new Phrase("Applied job id"));				t.addCell(c6);
					
					
					
					sql="select c.name,c.email,e.graduate,e.g_cgpa,e.passed_out_year,v.vacancy_id "
							+ " from  educational_details as e inner join candidate as c on c.id=e.cand_id inner join candidate_vacancy as v "
							+ "on c.id=v.cand_id inner join company_vacancy cv on v.vacancy_id=cv.vacancy_id where v.status ='"+status+"' "
									+ " AND cv.company_id='"+success+"'"+ " AND e.graduate='"+graduate+"'";
				
					    rs=stmt.executeQuery(sql);
				while(rs.next()){
					
					
						//pstmt.setInt(1, rs.getInt("canid"));
						//rs2=pstmt.executeQuery();
					
					t.addCell(rs.getString(1));
					
					t.addCell(rs.getString(2));
					
					t.addCell(rs.getString(3));
					
					t.addCell(rs.getString(4));
					
					t.addCell(rs.getString(5));
					t.addCell(rs.getString(6));
					
					
					
						
						
				}
				document.add(t);
				document.close();
				System.out.println("\tPDF download complete");
				
			}catch(SQLException ex){
					ex.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
	
	
	
	
	
	
}

