package com.placement;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {
	
	public static boolean validateLetters(String txt){
		if(Pattern.matches("[a-zA-Z ]+", txt)){
			return true;
		}
		else{
			return false;
		}
		
	}
	
	public static boolean validateExp(String exp) {
		Pattern pattern = Pattern.compile("\\d{1}");
		Matcher matcher = pattern.matcher(exp);
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
	}
     
	public static boolean validatePhoneNumber(String mob) {
		Pattern pattern = Pattern.compile("\\d{10}");
		Matcher matcher = pattern.matcher(mob);
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
	}
	
	public static boolean validatePincode(String pin) {
		Pattern pattern = Pattern.compile("\\d{6}");
		Matcher matcher = pattern.matcher(pin);
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
	}
	
	public static boolean validateYear(String year) {
		Pattern pattern = Pattern.compile("\\d{4}");
		Matcher matcher = pattern.matcher(year);
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
	}
	
         
	/* (?=.*[0-9]) a digit must occur at least once
    (?=.*[a-z]) a lower case letter must occur at least once
    (?=.*[A-Z]) an upper case letter must occur at least once
    (?=.*[@#$%^&+=]) a special character must occur at least once
    (?=\\S+$) no whitespace allowed in the entire string
    .{8,} at least 8 characters*/

	public static boolean validatePass(String pass) {
		Pattern pattern =Pattern.compile("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
		Matcher matcher = pattern.matcher(pass);
		if (matcher.matches()) {
			return true;
		}
		else{
    		    	  return false;
    	}
        	      
	}
	
	
	
	
	
	public static boolean timeValidation(String pass) {
		Pattern pattern =Pattern.compile("^ ([01]?[0-9]|2[0-3]):[0-5][0-9]$");
		Matcher matcher = pattern.matcher(pass);
		if (matcher.matches()) {
			return true;
		}
		else{
    		    	  return false;
    	}
        	      
	}
	
         
	public static boolean validateEmail(String email) {
		Pattern pattern =Pattern.compile("^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$");
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
   	 }
	
	public static boolean validateURL(String url) {
		Pattern pattern =Pattern.compile("^(http://|https://)?(www.)?([a-zA-Z0-9]+).[a-zA-Z0-9]*.[a-z]{3}.?([a-z]+)?$");
		Matcher matcher = pattern.matcher(url);
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
   	 }
	//Date should be in format :dd-mmm-yyyy eg:12-JAN-2017
	public static boolean validateDate(String date) {
		Pattern pattern =Pattern.compile("^([0]?[1-9]|[1-2]\\d|3[0-1])-(JAN|FEB|MAR|APR|MAY|JUN|JULY|AUG|SEP|OCT|NOV|DEC)-[1-2]\\d{3}$", 'i');
		Matcher matcher = pattern.matcher(date);
	//	/^(19[5-9]\d|20[0-4]\d|2050)$/
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
   	 }
	
	
	
	public static boolean validateDob(String date) {
		Pattern pattern =Pattern.compile("^[0-3]{1}[0-9]{1}/[0-1]{1}[1-2]{1}/199[0-9]|20[0-9]$");
		Matcher matcher = pattern.matcher(date);
	
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
   	 }
	/*public static boolean validateDob2() {
		Pattern pattern =Pattern.compile("^[0-3]{1}[0-9]{1}/[0-1]{1}[1-2]{1}/199[0-9]|20[0-9]$");
		Matcher matcher = pattern.matcher(date);
	
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
   	 }*/
	
	
	public static boolean validateDob1(int yr) {
		
	
		if (+yr >= 1990 && +yr <= 2010) {
			return true;
		}
		else{
			return false;
		}
   	 }
	
	
	
	//(([1-9])|(0[1-9])|(1[0-2]))\/(([0-9])|([0-2][0-9])|(3[0-1]))\/(([0-9][0-9])|([1-2][0,9][0-9][0-9]))
	
	public static boolean validateYear1(String date) {
		Pattern pattern =Pattern.compile("^201[3-8]$");
		Matcher matcher = pattern.matcher(date);
		//199[0-9]|200[0-9]|201[0-8]
	//	/^(19[5-9]\d|20[0-4]\d|2050)$/
		if (matcher.matches()) {
			return true;
		}
		else{
			return false;
		}
   	 }
	public boolean memberidValidation(String member_id) {
        
	      //String passwd = "aaZZa44@"; 
	      Pattern pattern =Pattern.compile("^[a-zA-Z0-9]+$");
	      Matcher matcher = pattern.matcher(member_id);
	      if (matcher.matches()) {
	    	  return true;
	      }
	      else
	      {
	    	  return false;
	      }
	      
	   }

	
	
}
