package com.placement;

public class PLIDS {

	private String PLID; //PLID of candidates
	private String batch; //Name of batch
	private String crs_name; //course name of candidate
	private String year; //year of batch
	//private String email; //E-mail of candidate
	
	public PLIDS() {
		super();
	}
	
	public PLIDS(String pLID) {
		super();
		this.PLID = pLID;
		
	//	this.email = email;
	}

	public PLIDS(String pLID, String batch, String crs_name, String year) {
		super();
		PLID = pLID;
		this.batch = batch;
		this.crs_name = crs_name;
		this.year = year;
	//	this.email = email;
	}

	public String getPLID() {
		return PLID;
	}

	public void setPLID(String pLID) {
		PLID = pLID;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public String getCrs_name() {
		return crs_name;
	}

	public void setCrs_name(String crs_name) {
		this.crs_name = crs_name;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	
	
}
