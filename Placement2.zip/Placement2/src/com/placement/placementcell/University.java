package com.placement.placementcell;

public class University {
	
	private String university_id;
	private String university_name;
	//private College college;
	
	public University(){
		
	}
	public University(String university_id){
	this.university_id = university_id;
		
	}
	
	//parameterized constructor
	public University(String university_id, String university_name) {
		super();
		this.university_id = university_id;
		this.university_name = university_name;
		//this.college = college;
	}

	public String getUniversity_id() {
		return university_id;
	}

	public void setUniversity_id(String university_id) {
		this.university_id = university_id;
	}

	public String getUniversity_name() {
		return university_name;
	}

	public void setUniversity_name(String university_name) {
		this.university_name = university_name;
	}

	
	
	
	
	
	
	
	

}
