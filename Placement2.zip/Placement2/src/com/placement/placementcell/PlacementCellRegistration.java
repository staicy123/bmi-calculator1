package com.placement.placementcell;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.placement.PlacementDatabase;
import com.placement.PrimaryActionListener;
import com.placement.Validation;

public class PlacementCellRegistration implements PrimaryActionListener{
	Validation valid= new Validation();
	College coll = null;
	PlacementDatabase db = new PlacementDatabase();
	
	private College college;
	private String name;
	private String mobile;
	private String email;
	private String password;
	public PlacementCellRegistration() {
		super();
	}
	public PlacementCellRegistration(College college, String name,
			String mobile, String email, String password) {
		super();
		this.college = college;
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.password = password;
	}
	public College getCollege() {
		return college;
	}
	public void setCollege(College college) {
		this.college = college;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void register() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		String college_id=null,name,mobile,email,password;
		boolean status,status1=false;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		List<College> col = db.getCollegeList();
		System.out.println("College id\tCollege name    ");
		//for(;;){
				for(int i=0 ; i<col.size(); i++){
				
				System.out.println(col.get(i).getCollege_id()+"\t\t"+col.get(i).getCollege_name());
				}
				do{
					System.out.println("Select college id");
					college_id=br.readLine();
					for(int i=0 ; i<col.size(); i++){
						if(college_id.equals(col.get(i).getCollege_id())){
							status1=true;
							break;
							}
					}
						if(status1==false){
							System.out.println("Enter valid id from the above list");
							//status1=false;
							break;
						
						}
					
				}while(status1!=true);
				
		
		for(;;)
		{
			System.out.println("Enter the placement officer name");
			name=br.readLine();
			status=valid.validateLetters(name);
			if(status)
				break;
			else
			{
				System.out.println("Wrong Input");
			}
		}
		for(;;)
		{
			System.out.println("Enter mobile number");
			mobile=br.readLine();
			status=valid.validatePhoneNumber(mobile);
			if(status)
				break;
			else
			{
				System.out.println("Wrong input");
			}
		}
		for(;;){
			System.out.println("Enter email id");
			email=br.readLine();
			status=valid.validateEmail(email);
			if(status)
				break;
			else
			{
				System.out.println("Wrong input");
			}
		}
		//for(;;){
			System.out.println("Enter password");
			password=br.readLine();
		//	status=valid.validatePass(password);
			/*if(status)
				break;
			else
			{
				System.out.println("Wrong input");
			}
		}
		*/
		coll= new College(college_id);
		PlacementCellRegistration place= new PlacementCellRegistration(coll,name,mobile,email,password);
		place.db.placementRegister(place);
		
		
		
		
	}
	
	public String[] login(List<PlacementCellRegistration> place,BufferedReader br) throws IOException
	{
		String email,password,id = null,email_id = null;
		int i=0;
		boolean status=false;
	do{
		System.out.println("Enter the emailid");
		email=br.readLine();
		System.out.println("Enter the password");
		password=br.readLine();
		
		for(i=0; i<place.size();i++){
			if(email.equals(place.get(i).getEmail()) && password.equals(place.get(i).getPassword()))
			{
				System.out.println("Successfully logged in");
				id=place.get(i).getCollege().getCollege_id();
				email_id=place.get(i).getEmail();
				status=true;
			
				break;
					
			}
			}
		if(status==false){
			System.out.println("Enter valid username and password");
			//status1=false;
			break;
		
		}
	
		}while(status!=true);
	return new String[]{id,email_id};
		/*do{
			System.out.println("Select college id");
			college_id=br.readLine();
			for(int i=0 ; i<col.size(); i++){
				if(college_id.equals(col.get(i).getCollege_id())){
					status1=true;
					break;
					}
			}
				if(status1==false){
					System.out.println("Enter valid id from the above list");
					//status1=false;
					break;
				
				}
			
		}while(status1!=true);*/

		
	
	}
	
	

}
