package com.placement.placementcell;

public class College {
	
	private String college_id;
	private String college_name;
	private String address;
	private String email;
	private String phone;
	//private String university_id;
	private University university;
	
	public College(){
		
	}
	public College(String college_id){
		
		this.college_id=college_id;
	}
	
	public College(String college_id, String college_name, String address,
			String email, String phone, 
			University university) {
		super();
		this.college_id = college_id;
		this.college_name = college_name;
		this.address = address;
		this.email = email;
		this.phone = phone;
		//this.university_id = university_id;
		this.university = university;
	}
	public String getCollege_id() {
		return college_id;
	}
	public void setCollege_id(String college_id) {
		this.college_id = college_id;
	}
	public String getCollege_name() {
		return college_name;
	}
	public void setCollege_name(String college_name) {
		this.college_name = college_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public University getUniversity() {
		return university;
	}
	public void setUniversity(University university) {
		this.university = university;
	}
	
	
	
	

}
