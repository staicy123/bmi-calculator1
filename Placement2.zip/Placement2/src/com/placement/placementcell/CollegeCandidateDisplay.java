package com.placement.placementcell;

public class CollegeCandidateDisplay {
	
	
	String candidate_name;
	String email;
	String postgraduation;
	String p_passed_out_year;
	String p_marks;
	String graduation;
	String g_passed_out_year;
	String g_marks;
	String college_id;
	public CollegeCandidateDisplay() {
		super();
	}
	public CollegeCandidateDisplay(String candidate_name, String email,
			String postgraduation, String p_passed_out_year, String p_marks,
			String graduation, String g_passed_out_year, String g_marks) {
		super();
		this.candidate_name = candidate_name;
		this.email = email;
		this.postgraduation = postgraduation;
		this.p_passed_out_year = p_passed_out_year;
		this.p_marks = p_marks;
		this.graduation = graduation;
		this.g_passed_out_year = g_passed_out_year;
		this.g_marks = g_marks;
	}
	
	
	public String getCollege_id() {
		return college_id;
	}
	public void setCollege_id(String college_id) {
		this.college_id = college_id;
	}
	public String getCandidate_name() {
		return candidate_name;
	}
	public void setCandidate_name(String candidate_name) {
		this.candidate_name = candidate_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPostgraduation() {
		return postgraduation;
	}
	public void setPostgraduation(String postgraduation) {
		this.postgraduation = postgraduation;
	}
	public String getP_passed_out_year() {
		return p_passed_out_year;
	}
	public void setP_passed_out_year(String p_passed_out_year) {
		this.p_passed_out_year = p_passed_out_year;
	}
	public String getP_marks() {
		return p_marks;
	}
	public void setP_marks(String p_marks) {
		this.p_marks = p_marks;
	}
	public String getGraduation() {
		return graduation;
	}
	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}
	public String getG_passed_out_year() {
		return g_passed_out_year;
	}
	public void setG_passed_out_year(String g_passed_out_year) {
		this.g_passed_out_year = g_passed_out_year;
	}
	public String getG_marks() {
		return g_marks;
	}
	public void setG_marks(String g_marks) {
		this.g_marks = g_marks;
	}
	
	
	

}
