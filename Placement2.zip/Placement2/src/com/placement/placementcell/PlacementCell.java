package com.placement.placementcell;

public class PlacementCell {

	//Pending
}
