package com.placement.placementcell;

public class PlacementOfficer {
	
	String college_id;
	String college_name;
	String placement_officer_name;
	String email;
	
	
	public PlacementOfficer() {
		super();
	}


	public PlacementOfficer(String college_id, String college_name,
			String placement_officer_name, String email) {
		super();
		this.college_id = college_id;
		this.college_name = college_name;
		this.placement_officer_name = placement_officer_name;
		this.email = email;
	}


	public String getCollege_id() {
		return college_id;
	}


	public void setCollege_id(String college_id) {
		this.college_id = college_id;
	}


	public String getCollege_name() {
		return college_name;
	}


	public void setCollege_name(String college_name) {
		this.college_name = college_name;
	}


	public String getPlacement_officer_name() {
		return placement_officer_name;
	}


	public void setPlacement_officer_name(String placement_officer_name) {
		this.placement_officer_name = placement_officer_name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}
	
	
	

	

}
