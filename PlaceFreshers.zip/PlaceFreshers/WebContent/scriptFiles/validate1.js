function callcourse(qual)
{
        var var2;
        if(window.XMLHttpRequest)
        {
            var2=new XMLHttpRequest();
        }
        else
        {
            var2=new ActiveXObject("Microsoft.XMLHTTP");
        }
        var2.onreadystatechange=function()
        {
            if(var2.readyState==4 && var2.status==200)
            {
                document.getElementById("courseid").innerHTML=var2.responseText;
            }
        }
        var2.open("post","listCourse.jsp?qual="+qual,true);
        var2.send();
}

function validateFName(First_Name)
{
    var alpha=/^[A-Za-z ]+$/;
    if(!(First_Name.match(alpha)))
    {
        document.getElementById("fnameid").innerHTML=" Only letters and white space allowed";
        document.form1.First_Name.value="";
        return false;
    }
    else
    {
        document.getElementById("fnameid").innerHTML="";
        return true;
    }
}

function validateLName(Last_Name)
{
    var alpha=/^[A-Za-z ]+$/;
    if(!(Last_Name.match(alpha)))
    {
        document.getElementById("lnameid").innerHTML=" Only letters and white space allowed";
        document.form1.Last_Name.value="";
        return false;
    }
    else
    {
        document.getElementById("lnameid").innerHTML="";
        return true;
    }
}

function validatePin(Pincode)
{
	var regExp=/^[1-9][0-9]{5}$/;
	if(!(Pincode.match(regExp)))
    {
        document.getElementById("pincodeid").innerHTML=" Not a valid pincode";
        document.form1.Pincode.value="";
        return false;
    }
    else
    {
        document.getElementById("pincodeid").innerHTML="";
        return true;
    }
}

function validateMob(Phone)
{
	var regExp=/^[789]\d{9}$/;
	if(!(Phone.match(regExp)))
    {
        document.getElementById("mobid").innerHTML=" Not a valid mobile Number";
        document.form1.Phone.value="";
        return false;
    }
    else
    {
        document.getElementById("mobid").innerHTML="";
        return true;
    }
}

function validatePlid(plid)
{
	var regExp=/^[P][L]\d{4}$/;
	if(!(plid.match(regExp)))
    {
        document.getElementById("plid").innerHTML=" Not a valid PLID";
        document.form1.plid.value="";
        return false;
    }
    else
    {
        document.getElementById("plid").innerHTML="";
        return true;
    }
}

function validateCEmail(){
	var mail1=document.form1.email.value;
	var mail2=document.form1.cemail.value;
	if(mail1==mail2){
		document.getElementById("cemailid").innerHTML="";
        return true;
	}
	else{
		document.getElementById("cemailid").innerHTML=" Email ID doesn't match";
        document.form1.cemail.value="";
        return false;
	}
}

function validatePassword(password){
	var regExp=/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
	if(!(password.match(regExp)))
    {
        document.getElementById("passwordid").innerHTML=" Not a valid Password";
        document.form1.password.value="";
        return false;
    }
    else
    {
        document.getElementById("passwordid").innerHTML="";
        return true;
    }
}

function validateCPassword(){
	var pass1=document.form1.password.value;
	var pass2=document.form1.cpassword.value;
	if(pass1==pass2){
		document.getElementById("cpasswordid").innerHTML="";
        return true;
	}
	else{
		document.getElementById("cpasswordid").innerHTML=" Password doesn't match";
        document.form1.cpassword.value="";
        return false;
	}
}

function validateCompany(company)
{
    var alpha=/^[A-Za-z ]+$/;
    if(!(company.match(alpha)))
    {
        document.getElementById("companyid").innerHTML=" Only letters and white space allowed";
        document.form1.company.value="";
        return false;
    }
    else
    {
        document.getElementById("companyid").innerHTML="";
        return true;
    }
}



